import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import './App.css'
import { analyzeDocumentTrust, analyzeDocumentTypeEvidence, buildDocumentContext, classifyDocumentTypeWithConfidence, documentTypeLabels, extractDocumentText, type DocumentType } from './documentParser'
import { analyzeSpeechTranscript, getSpeechRecognition, isSpeechRecognitionSupported, speechErrorMessage, type SpeechRecognitionLike } from './speechRecognition'
import { evaluateAnswers, type SilenceStats } from './evaluation'
import { requestAiEvaluation } from './aiEvaluation'
import { createInterimFeedback, evaluatorProfiles, evaluatorReplyTitle, generateEvaluatorQuestions, type EvaluatorId } from './evaluators'
import { detectLanguage, type SupportedLanguage } from './language'
import { startVoiceActivityTracking, type VoiceActivityTracker } from './voiceActivity'

type Stage = 'setup' | 'practice' | 'result'
type PracticeMode = '면접' | '발표' | '시험'

interface GrowthSnapshot {
  date: string
  score: number
  evaluatorId: EvaluatorId
  mode: PracticeMode
  language?: 'ko' | 'en'
  rhythmScore: number
  voiceUsed: boolean
  metrics: Pick<ReturnType<typeof evaluateAnswers>['metrics'], 'understanding' | 'evidenceScore' | 'logic' | 'delivery' | 'persuasion' | 'confidenceScore' | 'fillerCount' | 'longPauses'>
}

interface SpeechAnswerReview {
  transcript: string
  corrections: Array<{ before: string; after: string }>
}

const badgeDefinitions = [
  { id: 'first-practice', emoji: '🌱', ko: '첫 연습 완료', en: 'First practice', description: '성장의 첫 기준점을 만들었어요.' },
  { id: 'understanding-20', emoji: '🎯', ko: '질문 이해도 20점', en: 'Perfect understanding', description: '질문의 의도를 정확하게 파악했어요.' },
  { id: 'delivery-15', emoji: '🗣️', ko: '전달력 15점 이상', en: 'Clear delivery', description: '핵심을 안정적으로 전달했어요.' },
  { id: 'evidence-growth', emoji: '💡', ko: '근거 제시 +5 성장', en: 'Evidence growth +5', description: '이전보다 근거 활용이 크게 좋아졌어요.' },
  { id: 'personal-best', emoji: '📈', ko: '최고 기록 경신', en: 'New personal best', description: '자신의 이전 최고 점수를 넘어섰어요.' },
  { id: 'first-70', emoji: '⭐', ko: '첫 70점 달성', en: 'First 70', description: '실전형 답변의 좋은 기반을 완성했어요.' },
  { id: 'first-80', emoji: '🏆', ko: '첫 80점 달성', en: 'First 80', description: '높은 완성도의 답변을 만들어냈어요.' },
  { id: 'pressure-pass', emoji: '🔥', ko: '압박 면접 통과', en: 'Pressure interview passed', description: '압박 질문 속에서도 답변을 지켜냈어요.' },
  { id: 'no-fillers', emoji: '🎙️', ko: '습관어 없는 답변', en: 'Filler-free answers', description: '습관어 없이 또렷하게 말했어요.' },
  { id: 'no-long-pause', emoji: '⏱️', ko: '긴 침묵 없는 답변', en: 'No long pauses', description: '긴 멈춤 없이 흐름을 유지했어요.' },
  { id: 'rhythm-90', emoji: '🌊', ko: '발표 리듬 90점', en: 'Rhythm 90', description: '속도와 멈춤을 자연스럽게 조절했어요.' },
  { id: 'streak-3', emoji: '📅', ko: '3일 연속 연습', en: '3-day streak', description: '세 번의 꾸준한 성장을 이어갔어요.' },
  { id: 'streak-5', emoji: '👑', ko: '5일 연속 연습', en: '5-day streak', description: '꾸준한 연습을 멋지게 이어갔어요.' },
] as const

const emptySilenceStats = (): SilenceStats => ({ thinkingPauses: 0, longPauses: 0, midSpeechBreaks: 0 })
const growthHistoryKey = 'aijudge-growth-history-v1'
const earnedBadgesKey = 'aijudge-earned-badges-v1'
const lastSessionKey = 'aijudge-last-session-v1'
const evaluatorEnglishNames: Record<EvaluatorId, string> = {
  lumi: 'Lumi Coach',
  real: 'Jihoon Park',
  pressure: 'Pressure Interviewer',
  teacher: 'Cody Teacher',
  judge: 'Judge',
}
const modeEnglishNames: Record<PracticeMode, string> = {
  면접: 'Interview',
  발표: 'Presentation',
  시험: 'Exam',
}
const documentAnalysisEnglish: Record<string, string> = {
  '창업지원사업·사업계획 양식': 'Startup support · business plan format', '시장분석 포함': 'Includes market analysis', '예산·재무 항목 존재': 'Includes budget · financial items', '일정·추진계획 존재': 'Includes timeline · execution plan', '수익모델 항목 존재': 'Includes revenue model',
  '보도자료 표준 형식': 'Standard press release format', '작성자·담당자 표시': 'Author · contact listed', '보도자료 문체': 'Press release writing style', '발표 날짜 포함': 'Publication date included',
  '초록(Abstract) 포함': 'Abstract included', '참고문헌 포함': 'References included', '연구방법 포함': 'Research methods included', '연구결과 포함': 'Research results included', '학술 발행 정보 포함': 'Academic publication details included',
  '조항 구조 존재': 'Clause structure detected', '계약 당사자 표시': 'Contract parties listed', '기간·효력·해지 조건 포함': 'Includes term · validity · termination conditions', '서명·날인 항목 존재': 'Signature fields included',
  '사용 절차 포함': 'Usage procedure included', '안전·주의사항 포함': 'Safety precautions included', '문제 해결 안내 포함': 'Troubleshooting guidance included',
  '지원동기 포함': 'Motivation included', '경력·경험 포함': 'Career · experience included', '역량·성과 포함': 'Skills · achievements included', '입사 후 포부 포함': 'Future goals included',
  '학습목표 포함': 'Learning objectives included', '실천·행동 지침 포함': 'Practical guidance included', '문제·정답 구성 포함': 'Question · answer structure included', '사례·예시 포함': 'Examples included',
  '문서의 주요 표현과 구성 패턴이 해당 유형과 유사함': 'The wording and structure match this document type', '작성일과 자료 기준일을 확인해 주세요.': 'Check the publication date and data reference date.', '핵심 주장에 연결된 출처나 인용을 추가로 확인해 주세요.': 'Check the sources or citations supporting key claims.', '공식 원문 링크 또는 실제 발행 기관을 확인해 주세요.': 'Verify the official source URL or issuing organization.',
  '공식기관 자료 단서': 'Official-source signals', '학술자료 단서': 'Academic-source signals', '개인 작성 문서': 'Personal document', '출처 확인 필요': 'Source verification needed', '검증되지 않은 정보 가능성': 'Possibly unverified information', '추가 확인 권장': 'Additional verification recommended',
  '출처 표시': 'Source information', '인용·참고문헌': 'Citations · references', '공식기관 단서': 'Official-source signals', '내부 모순·과장 표현': 'Contradictions · exaggerated claims',
  '공식기관명과 보도자료 형식이 발행 출처 단서로 확인됩니다.': 'The agency name and press release format provide issuing-source signals.', '출처 또는 링크가 문서에서 확인됩니다.': 'A source or link is present in the document.', '출처나 원문 링크를 찾지 못했습니다.': 'No source or original-document link was found.', '공식기관의 1차 보도자료이므로 일반 참고문헌 형식은 필수 요소가 아닙니다.': 'As a primary official press release, a standard bibliography is not required.', '인용 또는 참고문헌 형식이 확인됩니다.': 'Citation or reference formatting is present.', '주장을 뒷받침하는 인용 형식을 추가로 확인해 주세요.': 'Check for citations supporting the claims.', '공식기관·교육기관을 나타내는 표현이 있습니다. 실제 발행 여부는 원문에서 확인해야 합니다.': 'Official or educational institution signals are present. Verify the original publication.', '공식기관 발행 자료임을 확인할 단서가 부족합니다.': 'There are insufficient signals of an official publisher.', '뚜렷한 과장 표현은 발견되지 않았습니다.': 'No clear exaggerated claims were detected.', '서로 다른 주장이나 반론 표현이 많아 문맥 확인이 필요합니다.': 'Multiple opposing statements were found; review their context.',
  '이 결과는 문서 내부 단서를 점검한 참고 정보입니다. 출처의 실제 존재, 최신성, 외부 사실의 진위까지 보장하지 않습니다.': 'This is a reference check based on internal document signals. It does not guarantee source existence, recency, or external factual accuracy.',
}
const translateDocumentAnalysis = (text: string, language: SupportedLanguage) => {
  if (language !== 'en') return text
  if (documentAnalysisEnglish[text]) return documentAnalysisEnglish[text]
  const sourceCount = text.match(/^출처·인용 단서 (\d+)개 확인$/)
  if (sourceCount) return `${sourceCount[1]} source · citation signals found`
  const oldYear = text.match(/^일부 자료는 (\d{4})년 기준일 수 있어 최신성 확인이 필요합니다\.$/)
  if (oldYear) return `Some data may be from ${oldYear[1]}; check whether it is current.`
  const suspicious = text.match(/^단정적이거나 과장될 수 있는 표현이 (\d+)개 감지됐습니다\.$/)
  if (suspicious) return `${suspicious[1]} potentially absolute or exaggerated expressions were detected.`
  return text
}
const questionEchoSimilarity = (question: string, answer: string) => {
  const normalize = (text: string) => text.toLowerCase().replace(/[^0-9a-z가-힣]/g, '')
  const questionText = normalize(question)
  const answerText = normalize(answer)
  if (questionText.length < 8 || answerText.length < questionText.length * 0.45) return 0
  const bigrams = (text: string) => {
    const result = new Set<string>()
    for (let index = 0; index < text.length - 1; index += 1) result.add(text.slice(index, index + 2))
    return result
  }
  const questionBigrams = bigrams(questionText)
  const answerBigrams = bigrams(answerText)
  const overlap = [...answerBigrams].filter((item) => questionBigrams.has(item)).length
  return (2 * overlap) / Math.max(1, questionBigrams.size + answerBigrams.size)
}
const withJosa = (word: string, consonant: string, vowel: string) => {
  const code = word.trim().charCodeAt(word.trim().length - 1)
  const hasBatchim = code >= 0xac00 && code <= 0xd7a3 && (code - 0xac00) % 28 !== 0
  return `${word}${hasBatchim ? consonant : vowel}`
}
const evaluatorEnglishTraits: Record<EvaluatorId, string[]> = {
  lumi: ['Live hints', 'Praise · improve · encourage'],
  real: ['No mid-session hints', 'Final evaluation'],
  pressure: ['Five follow-ups', 'Repeated evidence checks'],
  teacher: ['Understanding checks', 'Concept review'],
  judge: ['Differentiation · marketability', 'Feasibility · delivery'],
}
const evaluatorEnglishRecommendations: Record<EvaluatorId, string> = {
  lumi: 'Recommended for beginners',
  real: 'Real interview practice',
  pressure: 'Final interview preparation',
  teacher: 'Exam · presentation practice',
  judge: 'Business plan · IR pitch',
}

const consecutivePracticeDays = (snapshots: GrowthSnapshot[]) => {
  const days = [...new Set(snapshots.map((item) => item.date.slice(0, 10)))].sort().reverse()
  if (!days.length) return 0
  let streak = 1
  for (let index = 1; index < days.length; index += 1) {
    const previous = new Date(`${days[index - 1]}T00:00:00`)
    const current = new Date(`${days[index]}T00:00:00`)
    if (Math.round((previous.getTime() - current.getTime()) / 86400000) !== 1) break
    streak += 1
  }
  return streak
}

const countSpeechHabits = (text: string) => {
  const counts = new Map<string, number>()
  const koreanPattern = /(?:^|[\s,.!?])((?:음+|어+|아+|저기|저|그게|그러니까(?:요)?|뭐랄까))(?=$|[\s,.!?])/g
  for (const match of text.matchAll(koreanPattern)) {
    const raw = match[1]
    const label = /^음/.test(raw) ? '음' : /^어/.test(raw) ? '어' : /^아/.test(raw) ? '아' : /^그러니까/.test(raw) ? '그러니까' : raw
    counts.set(label, (counts.get(label) ?? 0) + 1)
  }
  for (const filler of text.match(/\b(?:um+|uh+|like|you know)\b/gi) ?? []) {
    const label = filler.toLowerCase().replace(/^um+$/, 'um').replace(/^uh+$/, 'uh')
    counts.set(label, (counts.get(label) ?? 0) + 1)
  }
  return [...counts.entries()].sort((a, b) => b[1] - a[1])
}

function App() {
  const [stage, setStage] = useState<Stage>('setup')
  const [fileName, setFileName] = useState('')
  const [documentText, setDocumentText] = useState('')
  const [documentTypeOverride, setDocumentTypeOverride] = useState<DocumentType | null>(null)
  const [trustCheckOpen, setTrustCheckOpen] = useState(false)
  const [fileStatus, setFileStatus] = useState<'idle' | 'reading' | 'ready' | 'error'>('idle')
  const [fileMessage, setFileMessage] = useState('')
  const [mode, setMode] = useState<PracticeMode>('면접')
  const [duration, setDuration] = useState('10분')
  const [languagePreference, setLanguagePreference] = useState<'auto' | SupportedLanguage>('auto')
  const [evaluatorId, setEvaluatorId] = useState<EvaluatorId>('real')
  const [questionIndex, setQuestionIndex] = useState(0)
  const [focusedQuestions, setFocusedQuestions] = useState<string[] | null>(null)
  const [answer, setAnswer] = useState('')
  const [answers, setAnswers] = useState<string[]>([])
  const [voiceAnswers, setVoiceAnswers] = useState<boolean[]>([])
  const [voiceDurations, setVoiceDurations] = useState<number[]>([])
  const [responseLatencies, setResponseLatencies] = useState<number[]>([])
  const [silenceStats, setSilenceStats] = useState<SilenceStats[]>([])
  const [currentSilenceStats, setCurrentSilenceStats] = useState<SilenceStats>(emptySilenceStats)
  const [currentSilenceSeconds, setCurrentSilenceSeconds] = useState(0)
  const [currentAnswerUsedVoice, setCurrentAnswerUsedVoice] = useState(false)
  const [voiceSeconds, setVoiceSeconds] = useState(0)
  const [voiceElapsedSeconds, setVoiceElapsedSeconds] = useState(0)
  const [voiceLevel, setVoiceLevel] = useState(0)
  const [voiceTrackingAvailable, setVoiceTrackingAvailable] = useState(true)
  const [uncertainWords, setUncertainWords] = useState<string[]>([])
  const [speechCorrections, setSpeechCorrections] = useState<Array<{ before: string; after: string }>>([])
  const [sessionSpeechCorrections, setSessionSpeechCorrections] = useState<Array<{ before: string; after: string }>>([])
  const [speechAnswerReviews, setSpeechAnswerReviews] = useState<Array<SpeechAnswerReview | null>>([])
  const [recording, setRecording] = useState(false)
  const [speechMessage, setSpeechMessage] = useState('')
  const [liveInterruption, setLiveInterruption] = useState('')
  const [interruptionCount, setInterruptionCount] = useState(0)
  const [lastInterruptionSecond, setLastInterruptionSecond] = useState(0)
  const [coachFeedback, setCoachFeedback] = useState('')
  const [aiEvaluation, setAiEvaluation] = useState<ReturnType<typeof evaluateAnswers> | null>(null)
  const [aiStatus, setAiStatus] = useState<'idle' | 'loading' | 'ready' | 'fallback'>('idle')
  const [aiError, setAiError] = useState('')
  const [previousSnapshot, setPreviousSnapshot] = useState<GrowthSnapshot | null>(null)
  const [historySnapshots, setHistorySnapshots] = useState<GrowthSnapshot[]>([])
  const [earnedBadgeIds, setEarnedBadgeIds] = useState<string[]>([])
  const [newBadgeIds, setNewBadgeIds] = useState<string[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)
  const fileReadIdRef = useRef(0)
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null)
  const committedTranscriptRef = useRef('')
  const latestAnswerRef = useRef('')
  const submittingAnswerRef = useRef(false)
  const interruptionRef = useRef(false)
  const recordingStartedAtRef = useRef(0)
  const currentResponseLatencyRef = useRef(0)
  const voiceActivityRef = useRef<VoiceActivityTracker | null>(null)
  const historySavedRef = useRef(false)
  const restoredSessionRef = useRef(false)

  const evaluator = evaluatorProfiles.find((profile) => profile.id === evaluatorId) ?? evaluatorProfiles[1]
  const detectedDocumentContext = useMemo(() => buildDocumentContext(documentText), [documentText])
  const documentTypeCandidates = useMemo(() => classifyDocumentTypeWithConfidence(documentText), [documentText])
  const documentContext = useMemo(() => ({
    ...detectedDocumentContext,
    documentType: documentTypeOverride ?? detectedDocumentContext.documentType,
  }), [detectedDocumentContext, documentTypeOverride])
  const documentTrust = useMemo(() => analyzeDocumentTrust(documentText), [documentText])
  const documentTypeEvidence = useMemo(() => analyzeDocumentTypeEvidence(documentText, documentContext.documentType), [documentContext.documentType, documentText])
  const detectedDocumentLanguage = useMemo(() => detectLanguage(documentText), [documentText])
  const language = languagePreference === 'auto' ? detectedDocumentLanguage : languagePreference
  const evaluatorDisplayName = language === 'en' ? evaluatorEnglishNames[evaluatorId] : evaluator.name
  const modeDisplayName = language === 'en' ? modeEnglishNames[mode] : mode
  const documentCriteria: Partial<Record<DocumentType, { ko: string[]; en: string[] }>> = {
    pressRelease: { ko: ['핵심 메시지·근거 정확성', '한계 이해·실천 전달'], en: ['Core message · evidence accuracy', 'Limits · practical guidance'] },
    educational: { ko: ['개념 이해·근거 설명', '적용 방법·전달력'], en: ['Concept understanding · evidence', 'Application · delivery'] },
    studyMaterial: { ko: ['개념 정확성·근거 활용', '논리 전개·적용'], en: ['Concept accuracy · evidence', 'Logic · application'] },
    paper: { ko: ['연구 목적·결과 이해', '근거 해석·연구 한계'], en: ['Purpose · findings', 'Evidence interpretation · limitations'] },
    contract: { ko: ['조항 이해·정확성', '위험 구분·적용'], en: ['Clause understanding · accuracy', 'Risk recognition · application'] },
    manual: { ko: ['절차 이해·정확성', '주의사항·실행 전달'], en: ['Procedure understanding · accuracy', 'Precautions · execution'] },
    resume: { ko: ['직무 적합성·경험 근거', '답변 구조·전달력'], en: ['Role fit · experience evidence', 'Answer structure · delivery'] },
    other: { ko: ['핵심 메시지·근거 이해', '논리 전개·전달력'], en: ['Core message · evidence', 'Logic · delivery'] },
  }
  const criteriaTraits = mode === '시험'
    ? (language === 'en' ? ['Concept accuracy', 'Evidence · application'] : ['개념 정확성', '근거·적용'])
    : documentContext.documentType !== 'businessPlan' && documentCriteria[documentContext.documentType]
      ? documentCriteria[documentContext.documentType]![language]
      : (language === 'en' ? evaluatorEnglishTraits[evaluatorId] : evaluator.traits)
  const generatedQuestions = useMemo(
    () => generateEvaluatorQuestions(evaluatorId, documentContext, mode, language),
    [documentContext, mode, evaluatorId, language],
  )
  const questions = focusedQuestions ?? generatedQuestions
  const evaluation = useMemo(
    () => evaluateAnswers(questions, answers, documentText, voiceAnswers, language, voiceDurations, responseLatencies, silenceStats),
    [questions, answers, documentText, voiceAnswers, language, voiceDurations, responseLatencies, silenceStats],
  )
  const echoAnswers = useMemo(
    () => questions.map((question, index) => questionEchoSimilarity(question, answers[index] ?? '') >= 0.56),
    [answers, questions],
  )
  const baseDisplayEvaluation = aiEvaluation ?? evaluation
  const displayEvaluation = useMemo(() => {
    const answeredCount = Math.min(questions.length, answers.length)
    const echoCount = echoAnswers.slice(0, answeredCount).filter(Boolean).length
    if (answeredCount === 0 || echoCount < Math.ceil(answeredCount * 0.75)) return baseDisplayEvaluation
    const metrics = {
      ...baseDisplayEvaluation.metrics,
      understanding: Math.min(baseDisplayEvaluation.metrics.understanding, 4),
      evidenceScore: Math.min(baseDisplayEvaluation.metrics.evidenceScore, 2),
      logic: Math.min(baseDisplayEvaluation.metrics.logic, 3),
      delivery: Math.min(baseDisplayEvaluation.metrics.delivery, 10),
      persuasion: Math.min(baseDisplayEvaluation.metrics.persuasion, 3),
    }
    const score = metrics.understanding + metrics.evidenceScore + metrics.logic + metrics.delivery + metrics.persuasion
    const echoImprovement = language === 'en'
      ? 'Most answers repeated the question. Begin with a direct conclusion, then add one document-based fact.'
      : '대부분의 답변이 질문을 반복했습니다. 질문을 되읽지 말고 결론부터 답한 뒤 문서 근거를 1개 덧붙이세요.'
    return {
      ...baseDisplayEvaluation,
      score,
      verdict: 'difficult' as const,
      metrics,
      improvements: [echoImprovement, ...baseDisplayEvaluation.improvements].slice(0, 3),
    }
  }, [answers.length, baseDisplayEvaluation, echoAnswers, language, questions.length])
  const verdict = displayEvaluation.verdict ?? (displayEvaluation.score >= 75 ? 'high' : displayEvaluation.score >= 55 ? 'potential' : 'difficult')
  const verdictContent = language === 'en'
    ? {
        high: ['🟢', 'High likelihood of passing', 'Your answers are persuasive enough for a real evaluation.'],
        potential: ['🟡', 'Possible after improvement', 'Strengthen the priority areas below before the real evaluation.'],
        difficult: ['🔴', 'Difficult in the current state', 'Rebuild the key answers and practice once more before the real evaluation.'],
      }[verdict]
    : {
        high: ['🟢', '합격 가능성 높음', '현재 답변은 실제 심사에서도 경쟁력을 기대할 수 있어요.'],
        potential: ['🟡', '보완 후 가능', '아래 핵심 항목을 보완하면 합격 가능성을 높일 수 있어요.'],
        difficult: ['🔴', '현재 상태로는 어려움', '핵심 답변을 다시 구성하고 한 번 더 연습하는 것을 권장해요.'],
      }[verdict]
  const metricPracticeGoals = [
    { score: displayEvaluation.metrics.understanding, metric: language === 'en' ? 'Question understanding' : '질문 이해도', label: language === 'en' ? 'Use the question’s key phrase in the first sentence' : '첫 문장에 질문의 핵심 표현 넣기', guide: language === 'en' ? 'Reflecting the question in your opening sentence will make your answer more directly relevant.' : '질문의 표현을 첫 문장에 받아 말하면 답변의 관련성을 바로 높일 수 있습니다.' },
    { score: displayEvaluation.metrics.evidenceScore, metric: language === 'en' ? 'Use of evidence' : '근거 제시', label: language === 'en' ? 'Add one number or document-based fact' : '숫자 또는 문서 근거 1개 추가하기', guide: language === 'en' ? 'Adding just one number or document-based fact can strengthen the score.' : '답변에 수치나 문서 내용을 하나만 추가해도 점수 향상을 기대할 수 있습니다.' },
    { score: displayEvaluation.metrics.logic, metric: language === 'en' ? 'Logical structure' : '논리 전개', label: language === 'en' ? 'Connect the reason and result in two sentences' : '이유와 결과를 두 문장으로 연결하기', guide: language === 'en' ? 'Explaining one reason and its result will make the answer easier to follow.' : '이유 한 문장과 그 결과 한 문장을 연결하면 답변 흐름이 더 명확해집니다.' },
    { score: displayEvaluation.metrics.delivery, metric: language === 'en' ? 'Delivery' : '전달력', label: language === 'en' ? 'State the conclusion in the opening sentence' : '첫 문장에 결론부터 말하기', guide: language === 'en' ? 'Leading with the conclusion will help listeners understand your point faster.' : '결론부터 시작하면 청중이 핵심을 더 빠르게 이해할 수 있습니다.' },
    { score: displayEvaluation.metrics.persuasion, metric: language === 'en' ? 'Persuasiveness' : '설득력', label: language === 'en' ? 'Add one concrete real-world example' : '실제 사례 1개 넣기', guide: language === 'en' ? 'A short experience or example can make the answer more persuasive.' : '짧은 경험이나 사례를 덧붙이면 설득력이 더 높아질 수 있습니다.' },
  ].sort((a, b) => a.score - b.score)
  const retryPriorities = metricPracticeGoals.slice(0, 3)
  const sourceSentences = documentText
    .split(/(?<=[.!?。])\s+|\n+/)
    .map((sentence) => sentence
      .replace(/^[\s•·▪■◆▶✓-]+/, '')
      .replace(/G\s*T\s*A\s*I/gi, 'GTAI')
      .replace(/O\s*ne\s*-?\s*Touch/gi, 'One-Touch')
      .replace(/티\s*업/g, '티업')
      .replace(/핵\s*심/g, '핵심')
      .replace(/경쟁\s*력/g, '경쟁력')
      .replace(/자\s*동\s*회\s*수/g, '자동 회수')
      .replace(/높\s*이/g, '높이')
      .replace(/휴\s*대/g, '휴대')
      .replace(/\s+/g, ' ')
      .trim())
    .filter((sentence) => sentence.length >= 12 && sentence.length <= 800)
    .filter((sentence) => !/(담당자|책임자|연락처|전화|팩스|보도시점|보도참고자료|배포일|배포\s*\d{4}|담당\s*부서|문의처|TF\b|☎|\d{2,4}-\d{3,4}-\d{4})/i.test(sentence))
  const sourceExcerpt = (pattern: RegExp, fallback = documentContext.coreClaim) => {
    const sentence = sourceSentences.find((item) => pattern.test(item)) || fallback
    const match = sentence.match(pattern)
    const matchIndex = match?.index ?? 0
    const start = Math.max(0, matchIndex - 35)
    const excerpt = sentence.slice(start, start + 170)
    return `${start > 0 ? '…' : ''}${excerpt}${start + 170 < sentence.length ? '…' : ''}`
      .replace(/[.!?。]+$/, '')
  }
  const createDocumentModelAnswer = (question: string) => {
    const topic = documentContext.primaryTopic
    const topicEun = withJosa(topic, '은', '는')
    const topicGa = withJosa(topic, '이', '가')
    const topicEul = withJosa(topic, '을', '를')
    const normalized = question.toLowerCase()
    const problem = sourceExcerpt(/불편|문제|어려|부담|통증|반복|고객|problem|difficulty|pain|burden|customer/i)
    const solution = sourceExcerpt(/해결|기능|방식|장착|버튼|원터치|자동|제공|개선|solve|feature|button|provide|improve/i, documentContext.supportingClaim)
    const customer = sourceExcerpt(/고객|사용자|골퍼|시니어|여성|대상|현장|customer|user|golfer|senior|women/i, problem)
    const evidence = sourceExcerpt(/검증|조사|수치|시장|판매|가격|원가|비용|매출|특허|validate|survey|market|price|cost|sales|patent/i, documentContext.supportingClaim)
    const surveyProof = sourceExcerpt(/83\s*%|54\s*명|45\s*명|설문조사|설문|survey|45\s+of\s+54/i, '')
    const fieldProof = sourceExcerpt(/20\s*년|캐디|현장|경력|20\+\s*years|caddie|field experience/i, '')
    const patentProof = sourceExcerpt(/특허|Patent Registered|patent/i, '')
    const proof = surveyProof || fieldProof || patentProof || evidence
    const budget = sourceExcerpt(/예산|자금|지원금|제작비|생산비|비용|원가|budget|funding|production cost|cost/i, evidence)
    const validationPlan = sourceExcerpt(/초기\s*100|100대|사용자 의견|반복 테스트|시장 검증|pilot|100 units|user feedback|market validation/i, surveyProof || evidence)
    const hasFinancialEvidence = sourceSentences.some((sentence) => /원가|마진|제조비|생산비|판매가|unit cost|margin|production cost|selling price/i.test(sentence))
    const speakingFact = (value: string, fallback = language === 'en' ? 'the document’s central point' : '문서의 핵심 내용') => {
      const cleaned = value
        .replace(/^[…\s"“”]+|[…\s"“”]+$/g, '')
        .split(/[①②③④⑤⑥⑦⑧⑨⑩]/)[0]
        .replace(/^[-–—·•*\d.\s]+/, '')
        .replace(/\s+/g, ' ')
        .trim()
      return (cleaned || fallback).slice(0, 85).replace(/[,:;\s]+$/, '')
    }

    if (mode === '시험') {
      const isCovidGuidance = /(코로나|COVID-?19)/i.test(documentText) && /(예방수칙|손.?씻기|환기|기침.?예절|prevention|handwashing|ventilation)/i.test(documentText)
      if (isCovidGuidance) {
        const weeks = documentText.match(/(\d+)\s*주\s*연속\s*증가/)?.[1]
        const patients = documentText.match(/입원환자(?:\s*수)?(?:는|가)?\s*(\d{1,4})\s*명/)?.[1]
        const trend = weeks ? `최근 코로나19 입원환자가 ${weeks}주 연속 증가했다` : '최근 코로나19 입원환자가 증가하는 추세다'
        const countEvidence = patients ? `병원급 표본감시 의료기관에서 확인된 입원환자는 ${patients}명이며, ${trend}` : trend
        const englishTrend = weeks ? `monitored COVID-19 hospitalizations increased for ${weeks} consecutive weeks` : 'monitored COVID-19 hospitalizations have recently increased'
        const englishCountEvidence = patients ? `the monitored hospitalizations reached ${patients} patients and ${englishTrend}` : englishTrend
        if (language === 'en') {
          if (/cannot|conclude|limit|overstatement/.test(normalized)) return 'The document supports an increase in monitored COVID-19 hospitalizations and the need to follow prevention guidelines. It does not prove an individual’s infection risk or guarantee that one action alone will prevent every infection.'
          if (/misunderstand|incorrect|wrong/.test(normalized)) return 'A common misunderstanding is that one preventive action can completely eliminate infection risk. The document recommends a combination of handwashing, indoor ventilation, and cough etiquette, so the appropriate conclusion is to practice these measures together.'
          if (/practice|action|apply|recommend/.test(normalized)) return 'The practical takeaway is to wash hands regularly, ventilate indoor spaces, and follow cough etiquette. These actions should be practiced consistently because the document reports an increase in monitored COVID-19 hospitalizations.'
          if (/evidence|number|fact|example/.test(normalized)) return `The strongest evidence is that ${englishCountEvidence}. This trend supports the document’s recommendation to reinforce everyday prevention measures.`
          return `The central message is that ${englishTrend}, so everyday prevention measures need renewed attention. The document specifically recommends handwashing, indoor ventilation, and cough etiquette.`
        }
        if (/말할 수 없는|단정|한계/.test(question)) return '문서로 확인할 수 있는 것은 코로나19 입원환자가 증가 추세이며 예방수칙 준수가 필요하다는 점입니다. 그러나 이 자료만으로 개인의 감염 가능성이나 특정 행동 하나가 감염을 완전히 막는다고 단정할 수는 없습니다.'
        if (/오해|잘못|틀렸/.test(question)) return '흔한 오해는 예방 행동 하나만으로 감염을 완전히 막을 수 있다는 생각입니다. 문서는 손 씻기, 실내 환기, 기침 예절을 함께 권고하므로 여러 예방수칙을 꾸준히 실천하는 것이 중요합니다.'
        if (/실천|방법|적용|권고/.test(question)) return '가장 먼저 실천할 내용은 손을 자주 씻고, 실내를 환기하며, 기침 예절을 지키는 것입니다. 문서에서 코로나19 입원환자 증가 추세를 제시한 만큼 일상에서 이 세 가지 수칙을 꾸준히 지키는 것이 중요합니다.'
        if (/근거|수치|사례|사실/.test(question)) return `가장 강한 근거는 ${countEvidence}는 사실입니다. 이 증가 추세는 손 씻기, 실내 환기, 기침 예절과 같은 예방수칙을 다시 강화해야 할 필요성을 보여줍니다.`
        return `핵심부터 말씀드리면 ${trend}는 점입니다. 문서는 이에 대한 대응으로 손 씻기, 실내 환기, 기침 예절을 권고하고 있으므로 이러한 예방수칙을 일상에서 꾸준히 실천해야 합니다.`
      }
      const centralMessage = sourceExcerpt(/핵심|중요|예방|감염|건강|주의|권고|main|important|prevent|infection|health|recommend/i)
      const cause = sourceExcerpt(/원인|때문|증가|감소|전파|감염|위험|cause|because|increase|spread|risk/i, centralMessage)
      const factualEvidence = sourceExcerpt(/\d|조사|결과|통계|사례|환자|research|result|survey|case|patient/i, documentContext.supportingClaim)
      const action = sourceExcerpt(/손.?씻|씻기|실천|예방|마스크|환기|권고|wash|practice|prevent|mask|ventilat|recommend/i, centralMessage)
      const centralFact = speakingFact(centralMessage)
      const causeFact = speakingFact(cause, centralFact)
      const evidenceFact = speakingFact(factualEvidence, centralFact)
      const actionFact = speakingFact(action, centralFact)
      if (language === 'en') {
        if (/evidence|number|fact|example/.test(normalized)) return `The strongest supporting point is ${evidenceFact}. The document uses this fact as evidence, so I would connect it directly to the conclusion instead of reciting the source.`
        if (/cause|background|why/.test(normalized)) return `The main reason is ${causeFact}. The document highlights this background, which explains why ${topic} deserves attention.`
        if (/practice|action|apply|recommend/.test(normalized)) return `The most practical action is ${actionFact}. I would apply it consistently because it responds directly to the issue explained in the document.`
        return `The key point is that ${centralFact}. The document supports this idea with ${evidenceFact}, so the important takeaway is to understand and apply it in context.`
      }
      if (/근거|수치|사례|사실/.test(question)) return `가장 중요한 근거는 ${evidenceFact}라는 점입니다. 문서에서도 이를 핵심 사실로 제시하고 있어, 결론과 직접 연결해 설명하는 것이 좋습니다.`
      if (/원인|배경|왜.*중요/.test(question)) return `가장 중요한 이유는 ${causeFact} 때문입니다. 문서에서도 이 배경을 강조하고 있어, 결국 ${topic}에 주의를 기울여야 한다고 생각합니다.`
      if (/실천|방법|적용|권고/.test(question)) return `가장 먼저 실천할 내용은 ${actionFact}입니다. 문서의 취지를 고려하면 이를 꾸준히 적용하는 것이 핵심이라고 생각합니다.`
      return `핵심부터 말씀드리면 ${centralFact}라는 점입니다. 문서에서도 ${evidenceFact}를 근거로 제시하고 있어, 결국 이 내용을 정확히 이해하고 상황에 맞게 적용하는 것이 중요합니다.`
    }

    if (language === 'en') {
      if (/cost|margin|price/.test(normalized)) return hasFinancialEvidence
        ? `The document provides this financial basis: “${sourceExcerpt(/unit cost|margin|production cost|selling price|cost/i, evidence)}.” I would verify it with supplier quotes and a pilot production run.`
        : 'The document does not yet specify unit cost or target margin. I would obtain supplier quotes, run a small pilot production, and then present a verified cost and margin instead of guessing.'
      if (/budget|funding|fail/.test(normalized)) return `A limited budget does not automatically mean failure. I would prioritize the prototype and customer validation using “${budget},” then expand production only after the core value is verified.`
      if (/why.*need|need.*now/.test(normalized)) return `${topic} is needed now because the document identifies “${problem}” and supports it with “${proof}.”`
      if (/number|effect|validate|market|demand/.test(normalized)) return `I would validate the effect with real customer behavior rather than an unsupported claim. The document provides “${proof},” and the next validation step is “${validationPlan}.”`
      if (/compet|different|replicate|better|counter/.test(normalized)) return `${topic}'s defensible difference is “${solution}.” I would answer the counterargument with the documented evidence “${proof}” and a direct comparison test.`
      if (/success|evidence|confident|proof/.test(normalized)) return `The strongest reason for confidence is “${proof}.” This is stronger than intuition because it connects field experience or customer validation to a documented need.`
      if (/how|solve|way|method/.test(normalized)) return `${topic} solves the problem through this documented approach: “${solution}.” This reduces the difficulty described as “${problem}.”`
      if (/example|situation|used/.test(normalized)) return `For example, in a situation involving “${customer},” ${topic} can be used through this function: “${solution}.”`
      if (/why|need|problem/.test(normalized)) return `${topic} is needed because the document identifies this problem: “${problem}.” This directly affects “${customer}.”`
      if (/what is|define/.test(normalized)) return `${topic} is the solution described in the document as “${solution}.” Its main purpose is to address “${problem}.”`
      return `My conclusion is based on this statement from the document: “${sourceExcerpt(/./)}.” The supporting evidence is “${evidence}.”`
    }

    if (/원가|마진|가격/.test(question)) return hasFinancialEvidence
      ? `문서의 재무 근거는 “${sourceExcerpt(/원가|마진|제조비|생산비|판매가/, evidence)}”입니다. 공급업체 견적과 소량 생산으로 이 수치를 다시 검증하겠습니다.`
      : '현재 문서에는 정확한 원가와 목표 마진이 제시되어 있지 않습니다. 추측해서 답하지 않고 공급업체 견적, 소량 생산, 유통비 계산을 거쳐 검증된 수치를 제시하겠습니다.'
    if (/예산|자금|지원금|실패/.test(question)) return `예산이 부족하다고 사업이 곧 실패하는 것은 아닙니다. “${budget}”을 기준으로 시제품과 고객 검증에 먼저 집중하고, 핵심 가치가 확인된 뒤 생산과 확장을 단계적으로 진행하겠습니다.`
    if (/왜.*필요|지금.*필요/.test(question)) return `${topicGa} 지금 필요한 이유는 문서의 “${problem}”이라는 고객 문제와 “${proof}”라는 검증 근거가 함께 확인되기 때문입니다.`
    if (/숫자|효과|검증|시장|수요/.test(question)) return `주장만으로 효과를 단정하지 않고 실제 고객 행동으로 검증하겠습니다. 문서의 “${proof}”를 출발점으로 “${validationPlan}”을 실행해 사용 만족도와 구매 의향을 측정하겠습니다.`
    if (/경쟁|차별|따라|낫지|반론|기존 방식/.test(question)) return `${topic}의 차별점은 “${solution}”입니다. “${proof}”라는 근거와 기존 방식과의 직접 비교 테스트로 반론에 답하겠습니다.`
    if (/성공|확신|결정적 근거|입증|강한 근거/.test(question)) return `성공 가능성을 판단한 가장 강한 근거는 “${proof}”입니다. 개인적인 확신이 아니라 현장 경험이나 고객 검증 결과가 문서의 문제 인식과 연결되어 있기 때문입니다.`
    if (/핵심 목적|목적을 객관/.test(question)) return `${topic}의 핵심 목적은 “${problem}”이라는 고객 불편을 “${solution}” 방식으로 해결하는 것입니다.`
    if (/문서 속 근거|뒷받침.*근거|근거는 무엇/.test(question)) return `필요성을 뒷받침하는 가장 강한 문서 속 근거는 “${proof}”입니다. 이는 개인의 추측이 아니라 현장 경험 또는 실제 고객 조사 결과입니다.`
    if (/어떤 방식|어떻게|해결/.test(question)) return `${topicEun} 문서에 나온 “${solution}” 방식으로 문제를 해결합니다. 이를 통해 “${problem}”이라는 불편을 줄입니다.`
    if (/사례|상황|사용/.test(question)) return `예를 들어 “${customer}”인 상황에서 ${topicEul} 사용할 수 있습니다. 이때 “${solution}” 기능으로 해당 불편을 해결합니다.`
    if (/왜|필요|문제/.test(question)) return `${topicGa} 필요한 이유는 문서에서 “${problem}”이라는 문제를 제시했기 때문입니다. 특히 “${customer}”에게 직접적인 불편이 됩니다.`
    if (/(?:은|는)\s*무엇(?:인가요|입니까)|정의/.test(question)) return `${topicEun} 문서에서 “${solution}”라고 설명한 제품입니다. 핵심 목적은 “${problem}”을 해결하는 것입니다.`
    return `결론은 문서의 “${sourceExcerpt(/./)}”라는 내용입니다. 이를 뒷받침하는 근거는 “${evidence}”입니다.`
  }
  const modelAnswers = questions.map((question, index) => displayEvaluation.modelAnswers?.[index]
    || createDocumentModelAnswer(question))
  const fallbackPredictedQuestions = (() => {
    const topic = documentContext.primaryTopic
    const topicEul = withJosa(topic, '을', '를')
    const topicGa = withJosa(topic, '이', '가')
    const examKo = [
      `${topic}에 관한 문서의 핵심 수치를 정확히 설명해 주십시오.`,
      `${topic}에 대해 사람들이 흔히 오해할 수 있는 점은 무엇입니까?`,
      `문서의 근거만으로 단정할 수 없는 내용은 무엇입니까?`,
      `${topic}에 관한 권고를 일상에서 어떻게 실천할 수 있습니까?`,
    ]
    const examEn = [
      `What is the most important numerical fact about ${topic} in the document?`,
      `What is a common misunderstanding about ${topic}?`,
      `What cannot be concluded from the document's evidence alone?`,
      `How can the document's recommendation be applied in daily life?`,
    ]
    if (mode === '시험') return (language === 'en' ? examEn : examKo).map((question) => ({
      question,
      modelAnswer: createDocumentModelAnswer(question),
    }))
    const ko = evaluatorId === 'pressure'
      ? [
          `${topicEul} 경쟁사가 더 낮은 가격으로 따라 하면 어떻게 대응할 겁니까?`,
          `${topic}의 원가와 목표 마진을 지금 설명하지 못하는 이유가 무엇입니까?`,
          `시장 검증이 부족한 상태에서 고객 수요를 확신하는 근거가 있습니까?`,
          `왜 하필 지금 ${topicGa} 필요하다고 보십니까?`,
        ]
      : evaluatorId === 'lumi'
        ? [
            `${topicEul} 고객이 선택할 가장 큰 이유는 무엇일까요?`,
            `${topic}의 예상 원가와 적절한 판매가는 얼마일까요?`,
            `고객 반응을 확인하기 위해 가장 먼저 어떤 검증을 해보면 좋을까요?`,
            `좋아요. ${topicGa} 지금 필요한 이유를 한 문장으로 말해볼까요?`,
          ]
        : [
            `경쟁사가 ${topicEul} 쉽게 따라 하기 어려운 이유는 무엇입니까?`,
            `${topic}의 예상 원가와 목표 마진은 얼마입니까?`,
            `고객 수요와 시장성을 어떤 방식으로 검증했습니까?`,
            `왜 ${topicGa} 지금 시장에 필요한 제품입니까?`,
          ]
    const en = [
      `Why would ${topic} be difficult for competitors to replicate?`,
      `What are the expected unit cost and target margin for ${topic}?`,
      `How have you validated customer demand for ${topic}?`,
      `Why does the market need ${topic} now?`,
    ]
    return (language === 'en' ? en : ko).map((question) => ({
      question,
      modelAnswer: createDocumentModelAnswer(question),
    }))
  })()
  const predictedQuestions = displayEvaluation.predictedQuestions?.length
    ? displayEvaluation.predictedQuestions
    : fallbackPredictedQuestions
  const audienceScores = displayEvaluation.audienceScores ?? evaluation.audienceScores
  const confidenceSummary = displayEvaluation.confidenceSummary || evaluation.confidenceSummary
  const oneLineActions = (displayEvaluation.retryPriorities?.length
    ? displayEvaluation.retryPriorities
    : retryPriorities.map((item) => item.label))
    .slice(0, 2)
  const oneLineSummary = language === 'en'
    ? `${displayEvaluation.title} Next, focus on ${oneLineActions.join(' and ').toLowerCase()}.`
    : `${displayEvaluation.title} 다음에는 ${oneLineActions.join('와 ')}에 집중해 보세요.`
  const growthMetrics = previousSnapshot ? [
    [language === 'en' ? 'Understanding' : '질문 이해도', previousSnapshot.metrics.understanding, displayEvaluation.metrics.understanding],
    [language === 'en' ? 'Evidence' : '근거 제시', previousSnapshot.metrics.evidenceScore, displayEvaluation.metrics.evidenceScore],
    [language === 'en' ? 'Logic' : '논리 전개', previousSnapshot.metrics.logic, displayEvaluation.metrics.logic],
    [language === 'en' ? 'Delivery' : '전달력', previousSnapshot.metrics.delivery, displayEvaluation.metrics.delivery],
    [language === 'en' ? 'Persuasion' : '설득력', previousSnapshot.metrics.persuasion, displayEvaluation.metrics.persuasion],
  ] : []
  const growthReason = previousSnapshot ? (() => {
    const changes = growthMetrics
      .map(([label, before, current]) => ({ label: String(label), delta: Number(current) - Number(before) }))
      .sort((a, b) => a.delta - b.delta)
    const totalDelta = displayEvaluation.score - previousSnapshot.score
    const mainChange = totalDelta < 0 ? changes[0] : [...changes].sort((a, b) => b.delta - a.delta)[0]
    if (language === 'en') {
      if (totalDelta === 0) return 'Your total score stayed the same. Review the category changes below to choose your next focus.'
      return totalDelta < 0
        ? `Your score decreased mainly because ${mainChange.label} changed by ${mainChange.delta} points.`
        : `Your score improved mainly because ${mainChange.label} increased by ${mainChange.delta} points.`
    }
    if (totalDelta === 0) return '총점은 같지만, 아래 항목별 변화를 확인하면 다음 연습의 우선순위를 정할 수 있어요.'
    return totalDelta < 0
      ? `오늘은 ${mainChange.label} 점수가 ${Math.abs(mainChange.delta)}점 낮아져 총점이 감소했습니다.`
      : `오늘은 ${mainChange.label} 점수가 ${mainChange.delta}점 높아져 총점이 향상되었습니다.`
  })() : ''
  const rhythmScore = evaluation.rhythmScore ?? 0
  const hasMeasuredVoice = voiceAnswers.some(Boolean) && evaluation.metrics.speakingPace > 0
  const hasSufficientVoiceSample = evaluation.metrics.voiceSampleSufficient > 0
  const rhythmPhases = evaluation.rhythmPhases ?? []
  const newlyUnlockedBadges = badgeDefinitions.filter((badge) => newBadgeIds.includes(badge.id))
  const earnedBadges = badgeDefinitions.filter((badge) => earnedBadgeIds.includes(badge.id))
  const speechSupported = typeof window !== 'undefined' && isSpeechRecognitionSupported()
  const currentQuestion = questions[questionIndex] ?? ''
  const isShortAnswerQuestion = /(?:계산|값은|몇\s*개|몇\s*명|숫자로|단어의 뜻|번역|영어로|한국어로|정답만)/.test(currentQuestion)
  const answerLength = answer.replace(/\s/g, '').length
  const wordSpeechCorrections = speechCorrections.filter((correction) => !/핵심부터 말하기|lead with the main point/i.test(correction.after))
  const suggestedSpeechAnswer = wordSpeechCorrections.reduce((text, correction) => {
    return text.split(correction.before).join(correction.after)
  }, answer)
  const speechHabitCounts = countSpeechHabits(answer)
  const voiceLengthStatus = voiceSeconds < 10 ? '너무 짧음' : voiceSeconds < 15 ? '조금 더 말해 보세요' : voiceSeconds <= 30 ? '적절' : voiceSeconds <= 60 ? '조금 김' : '너무 김'
  const textLengthStatus = answerLength < 30 ? '너무 짧음' : answerLength < 60 ? '조금 더 작성해 보세요' : answerLength <= 180 ? '적절' : answerLength <= 300 ? '조금 김' : '너무 김'
  const voiceProgress = Math.min(100, (voiceSeconds / 30) * 100)
  const voiceProgressTone = voiceSeconds < 15 ? 'short' : voiceSeconds <= 30 ? 'good' : 'long'
  const voiceProgressMessage = voiceSeconds < 10
    ? '조금만 더 설명해 보세요.'
    : voiceSeconds < 15
      ? '적절한 답변 구간에 거의 도착했어요.'
      : voiceSeconds <= 30
        ? '좋아요! 적절한 길이로 답변하고 있어요.'
        : voiceSeconds <= 60
          ? '핵심을 정리해 마무리해 보세요.'
          : '답변이 길어요. 결론부터 짧게 정리해 보세요.'

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(lastSessionKey) ?? 'null') as null | {
        questions: string[]; answers: string[]; voiceAnswers: boolean[]; voiceDurations: number[]; responseLatencies: number[]; silenceStats: SilenceStats[]
        speechAnswerReviews: Array<SpeechAnswerReview | null>; sessionSpeechCorrections: Array<{ before: string; after: string }>
        evaluation: ReturnType<typeof evaluateAnswers>; evaluatorId: EvaluatorId; mode: PracticeMode; duration: string
        languagePreference: 'auto' | SupportedLanguage; fileName: string; documentText: string
      }
      if (!saved?.answers?.length || !saved.questions?.length || !saved.evaluation) return
      restoredSessionRef.current = true
      setFocusedQuestions(saved.questions)
      setAnswers(saved.answers)
      setVoiceAnswers(saved.voiceAnswers ?? [])
      setVoiceDurations(saved.voiceDurations ?? [])
      setResponseLatencies(saved.responseLatencies ?? [])
      setSilenceStats(saved.silenceStats ?? [])
      setSpeechAnswerReviews(saved.speechAnswerReviews ?? [])
      setSessionSpeechCorrections(saved.sessionSpeechCorrections ?? [])
      setEvaluatorId(saved.evaluatorId)
      setMode(saved.mode)
      setDuration(saved.duration)
      setLanguagePreference(saved.languagePreference)
      setFileName(saved.fileName)
      setDocumentText(saved.documentText)
      setAiEvaluation(saved.evaluation)
      setAiStatus('ready')
      setStage('result')
    } catch {
      localStorage.removeItem(lastSessionKey)
    }
  }, [])

  useEffect(() => () => {
    recognitionRef.current?.abort()
    voiceActivityRef.current?.stop()
    voiceActivityRef.current = null
  }, [])
  useEffect(() => {
    if (stage !== 'practice') return
    currentResponseLatencyRef.current = 0
  }, [questionIndex, stage])
  useEffect(() => {
    if (stage !== 'result' || answers.length === 0) return
    if (restoredSessionRef.current) {
      restoredSessionRef.current = false
      return
    }
    let cancelled = false
    setAiStatus('loading')
    setAiError('')
    requestAiEvaluation({ questions, answers, documentText, documentType: documentContext.documentType, evaluatorId, mode, ruleEvaluation: evaluation, language })
      .then((result) => {
        if (cancelled) return
        setAiEvaluation(result)
        setAiStatus('ready')
      })
      .catch((error: unknown) => {
        if (cancelled) return
        setAiEvaluation(null)
        setAiError(error instanceof Error ? error.message : 'API_REQUEST_FAILED')
        setAiStatus('fallback')
      })
    return () => { cancelled = true }
  }, [stage, questions, answers, documentText, documentContext.documentType, evaluatorId, mode, evaluation, language])

  useEffect(() => {
    if (stage !== 'result' || answers.length === 0) return
    try {
      localStorage.setItem(lastSessionKey, JSON.stringify({
        questions, answers, voiceAnswers, voiceDurations, responseLatencies, silenceStats,
        speechAnswerReviews, sessionSpeechCorrections, evaluation: displayEvaluation,
        evaluatorId, mode, duration, languagePreference, fileName, documentText: documentText.slice(0, 250_000),
      }))
    } catch {
      // A very large document can exceed the browser storage quota. Keep the UI usable.
    }
  }, [stage, questions, answers, voiceAnswers, voiceDurations, responseLatencies, silenceStats, speechAnswerReviews, sessionSpeechCorrections, displayEvaluation, evaluatorId, mode, duration, languagePreference, fileName, documentText])
  useEffect(() => {
    if (stage !== 'result') return
    historySavedRef.current = false
    try {
      const history = JSON.parse(localStorage.getItem(growthHistoryKey) ?? '[]') as GrowthSnapshot[]
      setHistorySnapshots(history)
      setPreviousSnapshot([...history].reverse().find((item) => item.evaluatorId === evaluatorId && item.mode === mode && (item.language ?? 'ko') === language) ?? null)
      setEarnedBadgeIds(JSON.parse(localStorage.getItem(earnedBadgesKey) ?? '[]') as string[])
      setNewBadgeIds([])
    } catch {
      setPreviousSnapshot(null)
      setHistorySnapshots([])
    }
  }, [stage, evaluatorId, language, mode])
  useEffect(() => {
    if (stage !== 'result' || historySavedRef.current || !['ready', 'fallback'].includes(aiStatus)) return
    const snapshot: GrowthSnapshot = {
      date: new Date().toISOString(),
      score: displayEvaluation.score,
      evaluatorId,
      mode,
      language,
      rhythmScore: evaluation.rhythmScore ?? 0,
      voiceUsed: voiceAnswers.some(Boolean) && evaluation.metrics.voiceSampleSufficient > 0,
      metrics: {
        understanding: displayEvaluation.metrics.understanding,
        evidenceScore: displayEvaluation.metrics.evidenceScore,
        logic: displayEvaluation.metrics.logic,
        delivery: displayEvaluation.metrics.delivery,
        persuasion: displayEvaluation.metrics.persuasion,
        confidenceScore: displayEvaluation.metrics.confidenceScore,
        fillerCount: displayEvaluation.metrics.fillerCount,
        longPauses: displayEvaluation.metrics.longPauses,
      },
    }
    try {
      const history = JSON.parse(localStorage.getItem(growthHistoryKey) ?? '[]') as GrowthSnapshot[]
      const updatedHistory = [...history, snapshot].slice(-30)
      localStorage.setItem(growthHistoryKey, JSON.stringify(updatedHistory))
      setHistorySnapshots(updatedHistory)
      const previousSame = [...history].reverse().find((item) => item.evaluatorId === evaluatorId && item.mode === mode && (item.language ?? 'ko') === language)
      const unlocked = [
        history.length === 0 ? 'first-practice' : '',
        snapshot.metrics.understanding === 20 ? 'understanding-20' : '',
        snapshot.metrics.delivery >= 15 ? 'delivery-15' : '',
        previousSame && snapshot.metrics.evidenceScore - previousSame.metrics.evidenceScore >= 5 ? 'evidence-growth' : '',
        history.length > 0 && snapshot.score > Math.max(...history.map((item) => item.score)) ? 'personal-best' : '',
        snapshot.score >= 70 && !history.some((item) => item.score >= 70) ? 'first-70' : '',
        snapshot.score >= 80 && !history.some((item) => item.score >= 80) ? 'first-80' : '',
        evaluatorId === 'pressure' && snapshot.score >= 75 && !history.some((item) => item.evaluatorId === 'pressure' && item.score >= 75) ? 'pressure-pass' : '',
        snapshot.voiceUsed && snapshot.metrics.fillerCount === 0 ? 'no-fillers' : '',
        snapshot.voiceUsed && snapshot.metrics.longPauses === 0 ? 'no-long-pause' : '',
        snapshot.voiceUsed && snapshot.rhythmScore >= 90 ? 'rhythm-90' : '',
        consecutivePracticeDays(updatedHistory) >= 3 ? 'streak-3' : '',
        consecutivePracticeDays(updatedHistory) >= 5 ? 'streak-5' : '',
      ].filter(Boolean)
      const earned = JSON.parse(localStorage.getItem(earnedBadgesKey) ?? '[]') as string[]
      const newlyUnlocked = unlocked.filter((id) => !earned.includes(id))
      const updatedEarned = [...new Set([...earned, ...unlocked])]
      localStorage.setItem(earnedBadgesKey, JSON.stringify(updatedEarned))
      setNewBadgeIds(newlyUnlocked)
      setEarnedBadgeIds(updatedEarned)
      historySavedRef.current = true
    } catch {
      // 저장소를 사용할 수 없는 브라우저에서도 현재 평가는 그대로 제공합니다.
    }
  }, [aiStatus, displayEvaluation, evaluatorId, evaluation.metrics.speakingPace, evaluation.metrics.voiceSampleSufficient, evaluation.rhythmScore, language, mode, stage, voiceAnswers])

  const stopVoiceInput = () => {
    recognitionRef.current?.stop()
    voiceActivityRef.current?.stop()
    voiceActivityRef.current = null
    setRecording(false)
  }

  const toggleVoiceInput = async () => {
    if (recording) {
      stopVoiceInput()
      return
    }

    const recognition = getSpeechRecognition()
    if (!recognition) {
      setSpeechMessage('이 브라우저는 음성 입력을 지원하지 않습니다. Chrome 또는 Edge에서 이용해 주세요.')
      return
    }

    recognitionRef.current?.abort()
    voiceActivityRef.current?.stop()
    voiceActivityRef.current = null
    recognitionRef.current = recognition
    committedTranscriptRef.current = answer.trim()
    setSpeechMessage('마이크 권한을 허용하고 답변을 말해 주세요.')
    recognition.lang = language === 'en' ? 'en-US' : 'ko-KR'
    recognition.continuous = true
    recognition.interimResults = true
    recognition.maxAlternatives = 1

    const activeBase = voiceSeconds
    const elapsedBase = voiceElapsedSeconds
    const silenceBase = currentSilenceStats
    try {
      recordingStartedAtRef.current = Date.now()
      voiceActivityRef.current = await startVoiceActivityTracking({
        onSample: (sample) => {
          setVoiceSeconds(Math.round((activeBase + sample.activeSeconds) * 10) / 10)
          setVoiceElapsedSeconds(Math.round((elapsedBase + sample.elapsedSeconds) * 10) / 10)
          setVoiceLevel(sample.level)
          setCurrentSilenceSeconds(sample.currentSilenceSeconds)
          setCurrentSilenceStats({
            thinkingPauses: silenceBase.thinkingPauses + sample.thinkingPauses,
            longPauses: silenceBase.longPauses + sample.longPauses,
            midSpeechBreaks: silenceBase.midSpeechBreaks + sample.midSpeechBreaks,
          })
        },
        onFirstSpeech: (elapsedSeconds) => {
          if (!currentResponseLatencyRef.current) {
            currentResponseLatencyRef.current = elapsedSeconds
          }
        },
      })
      setVoiceTrackingAvailable(true)
    } catch {
      setVoiceTrackingAvailable(false)
      setSpeechMessage(language === 'en'
        ? 'Voice input is available, but precise speaking-time measurement could not start.'
        : '음성 입력은 가능하지만 실제 발화 시간 측정을 시작하지 못했습니다.')
    }

    recognition.onresult = (event) => {
      let finalTranscript = ''
      let interimTranscript = ''
      let finalConfidence = 1
      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        const transcript = event.results[index][0]?.transcript ?? ''
        if (event.results[index].isFinal) {
          finalTranscript += transcript
          const confidence = event.results[index][0]?.confidence ?? 1
          if (confidence > 0) finalConfidence = Math.min(finalConfidence, confidence)
        }
        else interimTranscript += transcript
      }
      if (!currentResponseLatencyRef.current && (finalTranscript.trim() || interimTranscript.trim())) {
        currentResponseLatencyRef.current = Math.max(0.1, Math.round((Date.now() - recordingStartedAtRef.current) / 100) / 10)
      }
      if (finalTranscript.trim() || interimTranscript.trim()) setCurrentAnswerUsedVoice(true)
      if (finalTranscript.trim()) {
        const analyzed = analyzeSpeechTranscript(finalTranscript.trim(), documentText, finalConfidence)
        committedTranscriptRef.current = [committedTranscriptRef.current, analyzed.text].filter(Boolean).join(' ')
        setUncertainWords((current) => [...new Set([...current, ...analyzed.uncertainWords])])
        setSpeechCorrections((current) => {
          const combined = [...current, ...analyzed.corrections]
          return combined.filter((item, index) => combined.findIndex((candidate) => candidate.before === item.before && candidate.after === item.after) === index)
        })
        setSessionSpeechCorrections((current) => {
          const combined = [...current, ...analyzed.corrections]
          return combined.filter((item, index) => combined.findIndex((candidate) => candidate.before === item.before && candidate.after === item.after) === index)
        })
      }
      const latestTranscript = [committedTranscriptRef.current, interimTranscript.trim()].filter(Boolean).join(' ')
      latestAnswerRef.current = latestTranscript
      setAnswer(latestTranscript)
      setSpeechMessage(interimTranscript ? '음성을 인식하고 있습니다…' : '답변을 계속 말씀해 주세요.')
    }

    recognition.onerror = (event) => {
      voiceActivityRef.current?.stop()
      voiceActivityRef.current = null
      setSpeechMessage(speechErrorMessage(event.error))
      setRecording(false)
    }

    recognition.onend = () => {
      voiceActivityRef.current?.stop()
      voiceActivityRef.current = null
      setRecording(false)
      recognitionRef.current = null
      if (interruptionRef.current) {
        setSpeechMessage(language === 'en' ? 'The evaluator has interrupted. Listen to the question, then continue.' : '평가자가 개입했습니다. 질문을 들은 뒤 답변을 이어가세요.')
        return
      }
      setSpeechMessage((current) => current.includes('문제') || current.includes('권한')
        ? current
        : '음성 입력이 완료되었습니다. 인식된 답변을 확인해 주세요.')
    }

    try {
      recognition.start()
      setRecording(true)
    } catch {
      voiceActivityRef.current?.stop()
      voiceActivityRef.current = null
      setSpeechMessage('음성 입력을 시작하지 못했습니다. 잠시 후 다시 시도해 주세요.')
      setRecording(false)
    }
  }

  const interruptLiveAnswer = useCallback((message: string) => {
    if (!recording || interruptionRef.current) return
    interruptionRef.current = true
    setLiveInterruption(message)
    setInterruptionCount((current) => current + 1)
    setLastInterruptionSecond(voiceSeconds)
    recognitionRef.current?.stop()
    voiceActivityRef.current?.stop()
    voiceActivityRef.current = null
    setRecording(false)
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(message)
      utterance.lang = language === 'en' ? 'en-US' : 'ko-KR'
      utterance.rate = evaluatorId === 'pressure' ? 0.95 : 1
      utterance.pitch = evaluatorId === 'pressure' ? 0.85 : 1
      window.speechSynthesis.speak(utterance)
    }
  }, [evaluatorId, language, recording, voiceSeconds])

  const resumeAfterInterruption = () => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    interruptionRef.current = false
    setLiveInterruption('')
    setSpeechMessage('')
    void toggleVoiceInput()
  }

  useEffect(() => {
    if (!recording || isShortAnswerQuestion || !['real', 'pressure', 'judge'].includes(evaluatorId)) return
    if (interruptionCount >= 2 || voiceSeconds < 18 || voiceSeconds - lastInterruptionSecond < 15) return
    const hasEvidence = /(?:\d|예를 들어|사례|조사|검증|시장|고객|원가|매출|근거|for example|evidence|survey|validation|market|customer|cost|revenue)/i.test(answer)
    let message = ''
    if (mode === '시험') {
      if (language === 'en') message = hasEvidence
        ? 'Please connect that fact to the concept the document is explaining.'
        : 'Please support that answer with one fact or example from the document.'
      else message = hasEvidence
        ? '잠시만요. 그 사실이 문서의 핵심 개념과 어떻게 연결되는지 설명해 주십시오.'
        : '잠시만요. 문서 속 수치나 사례 하나를 근거로 제시해 주십시오.'
    }
    else if (language === 'en') {
      if (!hasEvidence) message = evaluatorId === 'pressure'
        ? 'That is not enough evidence. What concrete fact supports your claim?'
        : evaluatorId === 'judge'
          ? 'Excuse me. Your market evidence is still unclear. Please explain it with a customer fact or number.'
          : 'Excuse me. Please clarify the evidence behind that point.'
      else if (voiceSeconds >= 38) message = evaluatorId === 'pressure'
        ? 'Stop there. State your conclusion in one sentence before continuing.'
        : 'Could you restate that point more concisely?'
    } else if (!hasEvidence) {
      message = evaluatorId === 'pressure'
        ? '잠시만요. 그 근거만으로는 부족합니다. 주장을 뒷받침하는 구체적인 사실은 무엇입니까?'
        : evaluatorId === 'judge'
          ? '잠시만요. 시장 근거가 아직 불분명합니다. 고객 반응이나 수치로 다시 설명해 주시겠습니까?'
          : '잠시만요. 그 판단의 근거를 조금 더 명확하게 설명해 주십시오.'
    } else if (voiceSeconds >= 38) {
      message = evaluatorId === 'pressure'
        ? '거기까지 듣겠습니다. 결론부터 한 문장으로 다시 말씀해 보세요.'
        : '그 부분을 조금 더 간결하게 다시 설명해 주시겠습니까?'
    }
    if (message) interruptLiveAnswer(message)
  }, [answer, evaluatorId, interruptionCount, interruptLiveAnswer, isShortAnswerQuestion, language, lastInterruptionSecond, mode, recording, voiceSeconds])

  const handleFile = async (file?: File) => {
    if (!file) return
    const readId = fileReadIdRef.current + 1
    fileReadIdRef.current = readId
    setDocumentTypeOverride(null)
    setTrustCheckOpen(false)
    setFileName(file.name)
    setDocumentText('')
    setFileStatus('reading')
    setFileMessage(language === 'en' ? 'Reading and analyzing the document…' : '문서 내용을 읽고 핵심을 분석하고 있습니다…')
    try {
      const text = await extractDocumentText(file)
      if (fileReadIdRef.current !== readId) return
      setDocumentText(text)
      setFileStatus('ready')
      setFileMessage(language === 'en' ? `Analyzed ${text.length.toLocaleString()} characters from the document.` : `${text.length.toLocaleString()}자의 문서 내용을 분석했습니다.`)
    } catch (error) {
      if (fileReadIdRef.current !== readId) return
      setFileStatus('error')
      setFileMessage(error instanceof Error ? error.message : (language === 'en' ? 'A problem occurred while reading the document.' : '문서를 읽는 중 문제가 발생했습니다.'))
    }
  }

  const startPractice = () => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    interruptionRef.current = false
    setLiveInterruption('')
    setInterruptionCount(0)
    setLastInterruptionSecond(0)
    setFocusedQuestions(null)
    setQuestionIndex(0)
    setAnswers([])
    setVoiceAnswers([])
    setVoiceDurations([])
    setResponseLatencies([])
    setSilenceStats([])
    setCurrentSilenceStats(emptySilenceStats())
    setCurrentSilenceSeconds(0)
    setCurrentAnswerUsedVoice(false)
    setVoiceSeconds(0)
    setVoiceElapsedSeconds(0)
    setVoiceLevel(0)
    setUncertainWords([])
    setSpeechCorrections([])
    setSessionSpeechCorrections([])
    setSpeechAnswerReviews([])
    latestAnswerRef.current = ''
    committedTranscriptRef.current = ''
    setAnswer('')
    recognitionRef.current?.abort()
    voiceActivityRef.current?.stop()
    voiceActivityRef.current = null
    setRecording(false)
    setSpeechMessage('')
    setCoachFeedback('')
    setAiEvaluation(null)
    setAiStatus('idle')
    setStage('practice')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const submitAnswer = () => {
    if (submittingAnswerRef.current) return
    submittingAnswerRef.current = true
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    interruptionRef.current = false
    setLiveInterruption('')
    setInterruptionCount(0)
    setLastInterruptionSecond(0)
    // 이전 질문의 비동기 음성 이벤트가 다음 질문 상태를 덮어쓰지 않도록
    // 제출 순간 핸들러와 마이크 분석기를 먼저 완전히 분리합니다.
    const recognition = recognitionRef.current
    recognitionRef.current = null
    if (recognition) {
      recognition.onresult = null
      recognition.onerror = null
      recognition.onend = null
      try { recognition.abort() } catch { /* 이미 종료된 인식기는 무시합니다. */ }
    }
    voiceActivityRef.current?.stop()
    voiceActivityRef.current = null
    const submittedAnswer = latestAnswerRef.current.trim()
    const pendingSilenceIsLong = currentSilenceSeconds >= 5
    const pendingSilenceIsThinking = currentSilenceSeconds >= 2 && currentSilenceSeconds < 4
    const finalizedSilenceStats = {
      thinkingPauses: currentSilenceStats.thinkingPauses + (pendingSilenceIsThinking ? 1 : 0),
      longPauses: currentSilenceStats.longPauses + (pendingSilenceIsLong ? 1 : 0),
      midSpeechBreaks: currentSilenceStats.midSpeechBreaks + (pendingSilenceIsLong || pendingSilenceIsThinking ? 1 : 0),
    }
    setAnswers((current) => [...current, submittedAnswer])
    setVoiceAnswers((current) => [...current, currentAnswerUsedVoice])
    setSpeechAnswerReviews((current) => [
      ...current,
      currentAnswerUsedVoice
        ? { transcript: submittedAnswer, corrections: [...speechCorrections] }
        : null,
    ])
    setVoiceDurations((current) => [...current, currentAnswerUsedVoice ? voiceSeconds : 0])
    setResponseLatencies((current) => [...current, currentAnswerUsedVoice ? currentResponseLatencyRef.current : 0])
    setSilenceStats((current) => [...current, currentAnswerUsedVoice ? finalizedSilenceStats : emptySilenceStats()])
    setCurrentAnswerUsedVoice(false)
    setVoiceSeconds(0)
    setVoiceElapsedSeconds(0)
    setVoiceLevel(0)
    setCurrentSilenceStats(emptySilenceStats())
    setCurrentSilenceSeconds(0)
    setUncertainWords([])
    setSpeechCorrections([])
    latestAnswerRef.current = ''
    committedTranscriptRef.current = ''
    setAnswer('')
    setRecording(false)
    setSpeechMessage('')
    if (questionIndex < questions.length - 1) setCoachFeedback(createInterimFeedback(evaluatorId, submittedAnswer, questions[questionIndex] ?? '', detectLanguage(submittedAnswer, language), mode))
    else setCoachFeedback('')
    if (questionIndex === questions.length - 1) {
      setStage('result')
    } else {
      setQuestionIndex((current) => current + 1)
    }
    window.setTimeout(() => { submittingAnswerRef.current = false }, 0)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const restart = () => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    interruptionRef.current = false
    setLiveInterruption('')
    setInterruptionCount(0)
    setLastInterruptionSecond(0)
    setQuestionIndex(0)
    setAnswers([])
    setVoiceAnswers([])
    setVoiceDurations([])
    setResponseLatencies([])
    setSilenceStats([])
    setCurrentSilenceStats(emptySilenceStats())
    setCurrentSilenceSeconds(0)
    setCurrentAnswerUsedVoice(false)
    setVoiceSeconds(0)
    setVoiceElapsedSeconds(0)
    setVoiceLevel(0)
    setUncertainWords([])
    setSpeechCorrections([])
    setSessionSpeechCorrections([])
    setSpeechAnswerReviews([])
    latestAnswerRef.current = ''
    committedTranscriptRef.current = ''
    setAnswer('')
    recognitionRef.current?.abort()
    voiceActivityRef.current?.stop()
    voiceActivityRef.current = null
    setRecording(false)
    setSpeechMessage('')
    setCoachFeedback('')
    setAiEvaluation(null)
    setAiStatus('idle')
    setStage('practice')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const practicePredictedQuestion = (question: string) => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    interruptionRef.current = false
    setLiveInterruption('')
    setInterruptionCount(0)
    setLastInterruptionSecond(0)
    recognitionRef.current?.abort()
    voiceActivityRef.current?.stop()
    voiceActivityRef.current = null
    setFocusedQuestions([question])
    setQuestionIndex(0)
    setAnswers([])
    setVoiceAnswers([])
    setVoiceDurations([])
    setResponseLatencies([])
    setSilenceStats([])
    setCurrentSilenceStats(emptySilenceStats())
    setCurrentSilenceSeconds(0)
    setCurrentAnswerUsedVoice(false)
    setVoiceSeconds(0)
    setVoiceElapsedSeconds(0)
    setVoiceLevel(0)
    setUncertainWords([])
    setSpeechCorrections([])
    setSessionSpeechCorrections([])
    setSpeechAnswerReviews([])
    latestAnswerRef.current = ''
    committedTranscriptRef.current = ''
    setAnswer('')
    setRecording(false)
    setSpeechMessage('')
    setCoachFeedback('')
    setAiEvaluation(null)
    setAiStatus('idle')
    setStage('practice')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <main>
      <header>
        <button className="brand" onClick={() => setStage('setup')} aria-label={language === 'en' ? 'AIJudge home' : 'AIJudge 홈'}>
          <span>A</span> AIJudge
        </button>
        <div className="header-actions">
          <label className="language-switcher">
            <span>{language === 'en' ? 'Language' : '언어'}</span>
            <select value={languagePreference} onChange={(event) => setLanguagePreference(event.target.value as 'auto' | SupportedLanguage)} aria-label={language === 'en' ? 'Practice language' : '연습 언어'}>
              <option value="auto">🌐 {language === 'en' ? 'Auto detect' : '자동 감지'}</option>
              <option value="ko">🇰🇷 한국어</option>
              <option value="en">🇺🇸 English</option>
            </select>
          </label>
          <nav aria-label={language === 'en' ? 'Main menu' : '주요 메뉴'}>
            <button onClick={() => setStage('setup')}>{language === 'en' ? 'New practice' : '새 연습'}</button>
            <button disabled title={language === 'en' ? 'Coming soon' : '준비 중'}>{language === 'en' ? 'History' : '연습 기록'}</button>
            <button className="login" disabled title={language === 'en' ? 'Coming soon' : '준비 중'}>{language === 'en' ? 'Sign in' : '로그인'}</button>
          </nav>
        </div>
      </header>

      {stage === 'setup' && (
        <>
          <section className="hero" id="top">
            <div className="hero-copy">
              <p className="eyebrow"><i /> AI SPEAKING EVALUATOR</p>
              <h1>{language === 'en' ? <>Turn preparation into<br /><em>confident speaking.</em></> : <>준비한 만큼,<br /><em>말할 수 있도록.</em></>}</h1>
              <p className="description">{language === 'en'
                ? <>AIJudge turns your documents into realistic interview, presentation, and exam practice.<br />It asks personalized questions, analyzes your spoken answers, and delivers actionable feedback—so you can speak with confidence.</>
                : <>AIJudge는 업로드한 문서를 이해하고 맞춤 질문을 생성합니다.<br />말하기 답변을 분석해 면접·발표·시험을 자신 있게 연습하도록 도와드립니다.</>}</p>
              <div className="promise-list">
                <span>✓ {language === 'en' ? 'Document-based questions' : '자료 기반 맞춤 질문'}</span>
                <span>✓ {language === 'en' ? 'Interview · presentation · exam practice' : '면접·발표·시험 실전 연습'}</span>
                <span>✓ {language === 'en' ? 'Actionable answer feedback' : '답변별 개선 피드백'}</span>
              </div>
            </div>

            <section className="setup-card" aria-label={language === 'en' ? 'Practice setup' : '연습 설정'}>
              <div className="setup-heading"><span>01</span><div><b>{language === 'en' ? 'Upload your practice material' : '연습 자료를 올려주세요'}</b><small>{language === 'en' ? 'AI reads your document and prepares questions.' : 'AI가 자료를 읽고 질문을 준비합니다.'}</small></div></div>
              <button className={`upload-zone ${fileName ? 'has-file' : ''}`} onClick={() => fileInputRef.current?.click()}>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.ppt,.pptx,.docx"
                  onChange={(event) => {
                    void handleFile(event.target.files?.[0])
                    event.currentTarget.value = ''
                  }}
                />
                <span className="upload-icon">↑</span>
                <b>{fileName || (language === 'en' ? 'Upload PDF, PPTX, or DOCX' : 'PDF, PPT, DOCX 파일 업로드')}</b>
                <small>{fileStatus === 'idle' ? (language === 'en' ? 'Click to choose a file · Up to 20MB' : '클릭해서 파일을 선택하세요 · 최대 20MB') : fileMessage}</small>
              </button>
              {fileStatus === 'error' && <p className="file-error" role="alert">{fileMessage}</p>}
              {fileStatus === 'ready' && (
                <div className="document-analysis-result" role="status">
                  <div className="document-type-result">
                    <span>📄</span>
                    <div><small>{language === 'en' ? 'Document analyzed' : '문서를 분석했습니다'}</small><b>{language === 'en' ? 'Document type' : '문서 유형'} · ✅ {documentTypeLabels[documentContext.documentType][language]}</b><em>{documentTypeOverride ? (language === 'en' ? 'Type confirmed by user' : '사용자가 확인한 유형') : `${language === 'en' ? 'Confidence' : '신뢰도'} ${(documentTypeCandidates[0]?.confidence ?? 100) >= 80 ? (language === 'en' ? '🟢 High' : '🟢 높음') : (documentTypeCandidates[0]?.confidence ?? 100) >= 55 ? (language === 'en' ? '🟡 Review' : '🟡 확인 필요') : (language === 'en' ? '🔴 Low' : '🔴 낮음')} · ${documentTypeCandidates[0]?.confidence ?? 100}%`}</em></div>
                  </div>
                  {(documentTypeCandidates[0]?.confidence ?? 100) < 80 && (
                    <div className="document-type-candidates">
                      <small>{language === 'en' ? 'The type is uncertain. Review the candidates and choose one.' : '판단이 애매합니다. 후보를 확인하고 유형을 선택해 주세요.'}</small>
                      <div>{documentTypeCandidates.map((candidate) => <span key={candidate.type}>{documentTypeLabels[candidate.type][language]} <b>{candidate.confidence}%</b></span>)}</div>
                    </div>
                  )}
                  <label className="document-type-select">{language === 'en' ? 'Choose type manually' : '유형 직접 선택'}
                    <select value={documentContext.documentType} onChange={(event) => setDocumentTypeOverride(event.target.value as DocumentType)}>
                      {Object.entries(documentTypeLabels).map(([type, labels]) => <option value={type} key={type}>{labels[language]}</option>)}
                    </select>
                  </label>
                  <div className="document-reasons">
                    <section><b>{language === 'en' ? 'Why AI chose this type' : 'AI가 판단한 이유'}</b>{documentTypeEvidence.features.map((feature) => <p key={feature}>✓ {translateDocumentAnalysis(feature, language)}</p>)}</section>
                    {documentTypeEvidence.cautions.length > 0 && <section className="cautions"><b>{language === 'en' ? 'Things to check' : '주의사항'}</b>{documentTypeEvidence.cautions.map((caution) => <p key={caution}>⚠ {translateDocumentAnalysis(caution, language)}</p>)}</section>}
                  </div>
                  <button className="trust-check-button" onClick={() => setTrustCheckOpen((current) => !current)}>🛡️ {language === 'en' ? 'Check sources · reliability' : '출처·신뢰도 확인'}</button>
                  {trustCheckOpen && (
                    <div className={`trust-analysis ${documentTrust.level}`}>
                      <div className="trust-summary"><span>{documentTrust.level === 'high' ? '🟢' : documentTrust.level === 'review' ? '🟡' : '🔴'}</span><div><small>{language === 'en' ? 'Automatic document reliability check' : '문서 신뢰도 자동 점검'}</small><b>{documentTrust.level === 'high' ? (language === 'en' ? 'High reliability' : '신뢰도 높음') : documentTrust.level === 'review' ? (language === 'en' ? 'Review recommended' : '확인 필요') : (language === 'en' ? 'Low reliability · caution' : '신뢰도 낮음 · 주의')}</b></div><strong>{documentTrust.score}</strong></div>
                      <div className="trust-badges">{documentTrust.badges.map((badge) => <span className={badge.tone} key={badge.label}>{badge.tone === 'green' ? '🟢' : badge.tone === 'blue' ? '🔵' : badge.tone === 'yellow' ? '🟡' : badge.tone === 'orange' ? '🟠' : '🔴'} {translateDocumentAnalysis(badge.label, language)}</span>)}</div>
                      <div className="trust-check-list">{documentTrust.checks.map((check) => <article className={check.status} key={check.label}><span>{check.status === 'good' ? '✓' : check.status === 'review' ? '!' : '⚠'}</span><div><b>{translateDocumentAnalysis(check.label, language)}</b><small>{translateDocumentAnalysis(check.detail, language)}</small></div></article>)}</div>
                      <p>{translateDocumentAnalysis(documentTrust.disclaimer, language)}</p>
                    </div>
                  )}
                </div>
              )}

              <div className="setup-heading section-heading"><span>02</span><div><b>{language === 'en' ? 'Choose a practice type' : '연습 상황을 선택하세요'}</b></div></div>
              <div className="mode-options">
                {(['면접', '발표', '시험'] as PracticeMode[]).map((item) => (
                  <button key={item} className={mode === item ? 'active' : ''} onClick={() => setMode(item)}>
                    <i>{item === '면접' ? '◉' : item === '발표' ? '▥' : '✓'}</i>
                    <b>{language === 'en' ? modeEnglishNames[item] : item}</b>
                  </button>
                ))}
              </div>

              <div className="setup-heading section-heading evaluator-heading"><span>03</span><div><b>{language === 'en' ? 'Choose your AI evaluator' : '평가자를 선택하세요'}</b><small>{language === 'en' ? 'Select the style that fits your practice goal.' : '원하는 연습 방식에 맞는 평가자를 고르세요.'}</small></div></div>
              <div className="evaluator-options">
                {evaluatorProfiles.map((profile) => (
                  <button key={profile.id} className={evaluatorId === profile.id ? 'active' : ''} onClick={() => setEvaluatorId(profile.id)}>
                    <span>{profile.emoji}</span>
                    <div><b>{language === 'en' ? evaluatorEnglishNames[profile.id] : profile.name}</b><small>{language === 'en' ? evaluatorEnglishRecommendations[profile.id] : profile.recommendation}</small><span className="trait-line">{(language === 'en' ? evaluatorEnglishTraits[profile.id] : profile.traits).join(' · ')}</span></div>
                    <div className={`difficulty ${profile.difficultyTone}`}><em>{language === 'en' ? 'Level' : '난이도'}</em><strong>{profile.difficulty}</strong></div>
                    <i>{evaluatorId === profile.id ? '✓' : ''}</i>
                  </button>
                ))}
              </div>

              <label className="duration-label">
                {language === 'en' ? 'Practice duration' : '연습 시간'}
                <select value={duration} onChange={(event) => setDuration(event.target.value)}>
                  <option value="5분">{language === 'en' ? '5 minutes' : '5분'}</option>
                  <option value="10분">{language === 'en' ? '10 minutes' : '10분'}</option>
                  <option value="20분">{language === 'en' ? '20 minutes' : '20분'}</option>
                  <option value="30분">{language === 'en' ? '30 minutes' : '30분'}</option>
                </select>
              </label>
              <button className="primary start-button" onClick={startPractice} disabled={fileStatus !== 'ready'}>
                {fileStatus === 'reading' ? (language === 'en' ? 'Analyzing document…' : '문서 분석 중…') : (language === 'en' ? 'Meet your AI evaluator' : 'AI 평가자 만나기')} <b>→</b>
              </button>
            </section>
          </section>
          <section className="features">
            <p>{language === 'en' ? 'Read, question, probe, and evaluate.' : '자료를 읽고, 질문하고, 파고들고, 평가합니다.'}</p>
            <div>
              <article><span>01</span><b>{language === 'en' ? 'Personalized questions' : '맞춤 질문'}</b><small>{language === 'en' ? 'Understands your document and asks about its core ideas.' : '업로드한 자료를 이해하고 핵심을 묻습니다.'}</small></article>
              <article><span>02</span><b>{language === 'en' ? 'Realistic follow-ups' : '실전 꼬리질문'}</b><small>{language === 'en' ? 'Probes gaps in your answer and asks for evidence.' : '답변의 빈틈과 근거를 자연스럽게 파고듭니다.'}</small></article>
              <article><span>03</span><b>{language === 'en' ? 'Speaking analysis' : '말하기 분석'}</b><small>{language === 'en' ? 'Evaluates logic, concision, and speaking habits.' : '논리, 간결성, 습관까지 종합 평가합니다.'}</small></article>
            </div>
          </section>
        </>
      )}

      {stage === 'practice' && (
        <section className="practice-page">
          <div className="session-bar">
            <div><i /> 실전 연습 중 <b>{mode} · {duration} · {evaluator.name}</b></div>
            <div>질문 {questionIndex + 1} / {questions.length}<button onClick={() => setStage('result')}>연습 종료</button></div>
          </div>
          <div className="practice-layout">
            <aside className="judge-panel">
              <div className="judge-avatar"><span>{evaluator.emoji}</span><i aria-hidden="true">|||||</i></div>
              <small>{language === 'en' ? 'Your AI evaluator is asking a question' : 'AI 평가자가 질문하고 있습니다'}</small>
              <h2>{evaluatorDisplayName}</h2>
              <p>{evaluator.shortName} · {evaluator.detail}</p>
              <div className="file-chip"><small>{language === 'en' ? 'Reference material' : '참고 중인 자료'}</small><b>{fileName || (language === 'en' ? 'Sample practice without a file' : '자료 없이 샘플 연습')}</b></div>
            </aside>
            <section className="answer-panel">
              <p className="question-number">QUESTION {String(questionIndex + 1).padStart(2, '0')}</p>
              <h1>{questions[questionIndex]}</h1>
              {coachFeedback && <div className={`coach-feedback reply-${evaluatorId}`}><span>{evaluator.emoji}</span><p><b>{evaluatorReplyTitle(evaluatorId, language)}</b>{coachFeedback}</p></div>}
              {liveInterruption && (
                <div className={`live-interruption ${evaluatorId}`} role="alert" aria-live="assertive">
                  <div className="interruption-pulse">{evaluator.emoji}</div>
                  <div><small>{language === 'en' ? 'LIVE INTERRUPTION' : '실시간 심사 개입'}</small><b>{evaluator.name}</b><p>“{liveInterruption}”</p></div>
                  <button onClick={resumeAfterInterruption}>{language === 'en' ? 'Continue answering' : '답변 계속하기'} <b>▶</b></button>
                </div>
              )}
              {questionIndex > 0 && evaluatorId !== 'lumi' && <p className={`follow-up ${evaluatorId === 'pressure' ? 'pressure' : ''}`}>↳ {language === 'en' ? (evaluatorId === 'pressure' ? 'This follow-up challenges the logic and evidence in your previous answer.' : 'This follow-up asks you to make your previous answer more specific.') : (evaluatorId === 'pressure' ? '이전 답변의 논리와 근거를 다시 검증합니다.' : '이전 답변을 더 구체적으로 확인하는 꼬리질문입니다.')}</p>}
              <div className="answer-box">
                <div className="answer-title"><b>{language === 'en' ? 'My answer' : '내 답변'}</b><small>{language === 'en' ? 'Answer by text or voice.' : '글 또는 음성으로 답변하세요.'}</small></div>
                <textarea
                  value={answer}
                  onChange={(event) => {
                    latestAnswerRef.current = event.target.value
                    setAnswer(event.target.value)
                  }}
                  placeholder={language === 'en' ? 'Lead with your conclusion, then add concrete evidence or experience.' : '결론부터 말하고, 구체적인 근거나 경험을 덧붙여 보세요.'}
                />
                <div className={`answer-length-guide ${isShortAnswerQuestion ? 'short-answer' : ''}`} aria-live="polite">
                  {isShortAnswerQuestion ? (
                    <><b>✓ 짧은 정답형 질문</b><span>숫자나 단어로 간단히 답해도 괜찮아요.</span></>
                  ) : currentAnswerUsedVoice ? (
                    voiceTrackingAvailable
                      ? <><b>🎙️ 실제 발화 {voiceSeconds}초 · {voiceLengthStatus}</b><span>권장 실제 발화 15~30초</span></>
                      : <><b>🎙️ 실제 발화 시간 측정 불가</b><span>받아쓰기 내용을 기준으로 평가합니다.</span></>
                  ) : (
                    <><b>✍️ {answerLength}자 · {textLengthStatus}</b><span>권장 글 답변 60~180자</span></>
                  )}
                </div>
                {currentAnswerUsedVoice && !isShortAnswerQuestion && voiceTrackingAvailable && (
                  <div className={`voice-time-progress ${voiceProgressTone}`} aria-live="polite">
                    <div className="voice-time-heading"><b>실제 발화 시간</b><span>전체 경과 {voiceElapsedSeconds}초 · 권장 발화 15~30초</span></div>
                    <div className="voice-time-labels"><span>0초</span><span>15초</span><span>30초</span></div>
                    <div className="voice-time-track">
                      <i className="recommended-zone" />
                      <em style={{ width: `${voiceProgress}%` }} />
                    </div>
                    <div className="voice-time-status"><b>{voiceSeconds}초 ({voiceLengthStatus})</b><span>{voiceProgressMessage}</span></div>
                    <div className="live-voice-level"><span>현재 음성 감지</span><i><em style={{ width: `${voiceLevel}%` }} /></i><b>{voiceLevel > 12 ? '말하는 중' : '침묵'}</b></div>
                  </div>
                )}
                {currentAnswerUsedVoice && (
                  <div className="speech-confidence-preview" data-testid="stt-correction-panel">
                    <b>{language === 'en' ? 'STT suggestions · speaking habits' : 'STT 추천 교정 · 말버릇 확인'}</b>
                    <div className="speech-sentence-comparison">
                      <div><small>{language === 'en' ? '🎤 AI heard' : '🎤 AI가 들은 내용'}</small><p>{answer}</p></div>
                      <div><small>{language === 'en' ? '💡 Suggested correction' : '💡 추천 교정'}</small><p>{suggestedSpeechAnswer}</p></div>
                    </div>
                    {uncertainWords.length > 0 && <p>{answer.split(/(\s+)/).map((part, index) => {
                      const cleanPart = part.replace(/[^가-힣A-Za-z0-9-]/g, '')
                      const uncertain = uncertainWords.some((word) => word === cleanPart || word.includes(cleanPart) && cleanPart.length >= 2)
                      return uncertain ? <mark key={`${part}-${index}`}>● {part}</mark> : <span key={`${part}-${index}`}>{part}</span>
                    })}</p>}
                    <small>{language === 'en' ? '※ Nothing was changed automatically. Review the suggestion and edit your answer if needed.' : '※ 자동으로 수정되지 않았습니다. 추천 내용을 확인한 뒤 필요하면 답변을 직접 수정해 주세요.'}</small>
                    {wordSpeechCorrections.length > 0 && (
                      <div className="speech-correction-table">
                        <div className="correction-header"><span>{language === 'en' ? '🔎 Recognized word' : '🔎 변경 전 단어'}</span><span>{language === 'en' ? 'Suggested word' : '변경된 단어'}</span></div>
                        {wordSpeechCorrections.map((correction) => (
                          <div className="correction-row" key={`${correction.before}-${correction.after}`}>
                            <span>{correction.before}</span><b>✅ {correction.after}</b>
                          </div>
                        ))}
                      </div>
                    )}
                    {wordSpeechCorrections.length === 0 && <p className="speech-empty-result">🔎 {language === 'en' ? 'No word corrections detected.' : '변경된 단어가 없습니다.'}</p>}
                    <div className="speech-habit-analysis">
                      <b>{language === 'en' ? '💬 Speaking habits' : '💬 말버릇 분석'}</b>
                      {speechHabitCounts.length > 0
                        ? <div>{speechHabitCounts.map(([habit, count]) => <span key={habit}>{habit} <strong>{count}{language === 'en' ? '×' : '회'}</strong></span>)}</div>
                        : <small>{language === 'en' ? 'No filler words detected in the recognized text.' : '인식된 문장에서 습관어가 감지되지 않았습니다.'}</small>}
                      <p>{language === 'en' ? 'Try pausing for one second instead of using a filler, then lead with your main point.' : '“음…” 같은 습관어 대신 1초 생각한 후 바로 핵심부터 말해 보세요.'}</p>
                    </div>
                  </div>
                )}
                <div className="answer-controls">
                  <button className={`voice-button ${recording ? 'recording' : ''}`} onClick={toggleVoiceInput} disabled={!speechSupported || Boolean(liveInterruption)}>
                    <span>{recording ? '■' : '●'}</span>{recording ? '음성 답변 중지' : `음성으로 답변 (${language === 'en' ? 'English' : '한국어'})`}
                  </button>
                  <button className="next-button" onClick={submitAnswer}>
                    {language === 'en' ? (questionIndex === questions.length - 1 ? 'View evaluation' : 'Next question') : (questionIndex === questions.length - 1 ? '평가 결과 보기' : '다음 질문')} →
                  </button>
                </div>
              </div>
              {(recording || speechMessage) && <p className={`recording-note ${recording ? 'is-listening' : ''}`} role="status">{speechMessage}</p>}
              {!speechSupported && <p className="recording-note" role="alert">이 브라우저에서는 음성 입력을 사용할 수 없습니다. Chrome 또는 Edge를 이용해 주세요.</p>}
            </section>
          </div>
        </section>
      )}

      {stage === 'result' && (
        <section className="result-page">
          <div className="result-heading">
            <p className="eyebrow"><i /> SESSION COMPLETE</p>
            <h1>{displayEvaluation.headline}<br /><em>{displayEvaluation.title}</em></h1>
            <p>{evaluatorDisplayName} · {modeDisplayName} {language === 'en' ? 'practice' : '연습'} · {duration} · {language === 'en' ? `${answers.length || questionIndex + 1} answers` : `${answers.length || questionIndex + 1}개 답변`}</p>
          </div>
          <section className="result-one-line" aria-label={language === 'en' ? 'Practice summary' : '이번 연습 한 줄 요약'}>
            <span>🏆</span>
            <div><b>{language === 'en' ? 'Practice summary' : '이번 연습 한 줄 요약'}</b><p>{oneLineSummary}</p></div>
          </section>
          <section className="score-card">
            <div className="score-circle"><b>{displayEvaluation.score}</b><small>/ 100</small></div>
            <div><span>{language === 'en' ? `${evaluatorDisplayName}'s overall evaluation` : `${evaluator.name}의 종합 평가`}</span><h2>{displayEvaluation.title}</h2><p>{displayEvaluation.summary}</p><div className="criteria-tags">{criteriaTraits.map((trait) => <i key={trait}>{trait}</i>)}</div></div>
          </section>
          <section className={`verdict-card ${verdict}`} aria-label={language === 'en' ? 'Expected assessment result' : '예상 심사 결과'}>
            <div className="verdict-label">{language === 'en' ? 'EXPECTED RESULT' : '예상 심사 결과'}</div>
            <div className="verdict-content"><span>{verdictContent[0]}</span><div><b>{verdictContent[1]}</b><p>{verdictContent[2]}</p></div></div>
            <small>{language === 'en' ? 'This is a practice estimate, not a guarantee of an actual result.' : '연습 답변을 기반으로 한 예상이며 실제 심사 결과를 보장하지 않습니다.'}</small>
          </section>
          <section className={`growth-card ${previousSnapshot ? '' : 'first'}`}>
            <div className="section-title"><span>🌱</span><div><b>{language === 'en' ? 'Your growth' : '나의 성장 기록'}</b><small>{previousSnapshot ? (language === 'en' ? 'Compared with your previous practice under the same conditions.' : '같은 평가자·연습 유형의 이전 기록과 비교했습니다.') : (language === 'en' ? 'This session becomes your first growth baseline.' : '이번 결과가 첫 성장 기준점으로 저장됩니다.')}</small></div></div>
            {previousSnapshot ? (
              <>
                <div className="growth-total"><div><small>{new Date(previousSnapshot.date).toLocaleDateString(language === 'en' ? 'en-US' : 'ko-KR')}</small><strong>{previousSnapshot.score}</strong></div><span>→</span><div><small>{language === 'en' ? 'Today' : '오늘'}</small><strong>{displayEvaluation.score}</strong></div><em className={displayEvaluation.score - previousSnapshot.score >= 0 ? 'up' : 'down'}>{displayEvaluation.score - previousSnapshot.score >= 0 ? '+' : ''}{displayEvaluation.score - previousSnapshot.score}</em></div>
                <p className="growth-first-message">{growthReason}</p>
                <div className="growth-metrics">{growthMetrics.map(([label, before, current]) => { const delta = Number(current) - Number(before); return <div key={String(label)}><b>{label}</b><span>{before} → <strong>{current}</strong></span><em className={delta >= 0 ? 'up' : 'down'}>{delta >= 0 ? '+' : ''}{delta}</em></div> })}</div>
              </>
            ) : <p className="growth-first-message">{language === 'en' ? 'Complete the same type of practice again to see score and skill changes here.' : '다음에 같은 유형으로 다시 연습하면 총점과 항목별 변화를 이곳에서 확인할 수 있어요.'}</p>}
          </section>
          {newlyUnlockedBadges.length > 0 && (
            <section className="new-badges" aria-live="polite">
              <div><span>🎉</span><div><b>{language === 'en' ? 'New badge unlocked!' : '새로운 배지를 획득했습니다!'}</b><small>{language === 'en' ? 'A small milestone that proves your growth.' : '이번 연습에서 만들어낸 소중한 성장 기록이에요.'}</small></div></div>
              <div className="new-badge-list">{newlyUnlockedBadges.map((badge) => <article key={badge.id}><span>{badge.emoji}</span><div><b>{language === 'en' ? badge.en : badge.ko}</b><small>{badge.description}</small></div></article>)}</div>
            </section>
          )}
          <details className="badge-collection">
            <summary><span>🏅</span><div><b>{language === 'en' ? 'My badge collection' : '나의 배지 컬렉션'}</b><small>{earnedBadges.length} / {badgeDefinitions.length} · {language === 'en' ? `${historySnapshots.length} practices recorded` : `${historySnapshots.length}개의 연습 기록`}</small></div><em>{language === 'en' ? 'View all' : '전체 보기'}</em></summary>
            <div className="badge-grid">{badgeDefinitions.map((badge) => { const earned = earnedBadgeIds.includes(badge.id); return <article className={earned ? 'earned' : 'locked'} key={badge.id}><span>{earned ? badge.emoji : '🔒'}</span><b>{language === 'en' ? badge.en : badge.ko}</b><small>{earned ? badge.description : (language === 'en' ? 'Keep practicing to unlock this badge.' : '연습을 이어가면 획득할 수 있어요.')}</small></article> })}</div>
          </details>
          <div className={`ai-evaluation-status ${aiStatus}`}>
            {aiStatus === 'loading' && (language === 'en' ? '✦ GPT‑5.6 is analyzing the meaning and context of your answers…' : '✦ GPT‑5.6이 답변의 의미와 문맥을 분석하고 있습니다…')}
            {aiStatus === 'ready' && (language === 'en' ? '✦ GPT‑5.6 semantic analysis + rule-based speaking metrics' : '✦ GPT‑5.6 의미 분석 + 규칙 기반 말하기 측정')}
            {aiStatus === 'fallback' && (aiError === 'API_KEY_MISSING'
              ? (language === 'en' ? 'Rule-based evaluation · The deployment API key is not configured.' : '규칙 기반 평가 · 배포 환경의 API 키가 설정되지 않았습니다.')
              : aiError === 'API_BILLING_REQUIRED'
                ? (language === 'en' ? 'Rule-based evaluation · Check OpenAI API credits and billing.' : '규칙 기반 평가 · OpenAI API 크레딧과 결제 설정을 확인해 주세요.')
                : aiError === 'API_MODEL_ACCESS'
                  ? (language === 'en' ? 'Rule-based evaluation · This API key cannot access the configured model.' : '규칙 기반 평가 · 현재 API 키로 설정된 모델을 사용할 수 없습니다.')
                  : (language === 'en' ? 'Rule-based evaluation · The GPT request failed temporarily.' : '규칙 기반 평가 · GPT 요청이 일시적으로 실패했습니다.'))}
          </div>
          <section className="score-breakdown" aria-label={language === 'en' ? 'Score breakdown' : '항목별 평가 점수'}>
            {[
              [language === 'en' ? 'Question understanding' : '질문 이해도', displayEvaluation.metrics.understanding],
              [language === 'en' ? 'Use of evidence' : '근거 제시', displayEvaluation.metrics.evidenceScore],
              [language === 'en' ? 'Logical structure' : '논리 전개', displayEvaluation.metrics.logic],
              [language === 'en' ? 'Delivery' : '전달력', displayEvaluation.metrics.delivery],
              [language === 'en' ? 'Persuasiveness' : '설득력', displayEvaluation.metrics.persuasion],
            ].map(([label, value]) => (
              <div className="score-metric" key={label}>
                <div><b>{label}</b><span><strong>{value}</strong> / 20</span></div>
                <i><em style={{ width: `${Number(value) * 5}%` }} /></i>
              </div>
            ))}
          </section>
          {hasMeasuredVoice && (
            <section className="confidence-card">
              <div className="confidence-score"><small>{language === 'en' ? 'CONFIDENCE DELIVERY' : '자신감 전달 지수'}</small><strong>{hasSufficientVoiceSample ? displayEvaluation.metrics.confidenceScore : '—'}</strong><span>{hasSufficientVoiceSample ? '/ 100' : (language === 'en' ? 'Insufficient data' : '측정 부족')}</span></div>
              <div className="confidence-detail"><b>{confidenceSummary}</b><div><span>{language === 'en' ? 'Response start' : '답변 시작'} <strong>{displayEvaluation.metrics.responseLatency || '-'}{displayEvaluation.metrics.responseLatency ? (language === 'en' ? 's' : '초') : ''}</strong></span><span>{language === 'en' ? 'Speaking pace' : '말하기 속도'} <strong>{displayEvaluation.metrics.speakingPace || '-'}{displayEvaluation.metrics.speakingPace ? (language === 'en' ? ' wpm' : '자/분') : ''}</strong></span></div><small>{language === 'en' ? 'This score reflects observable delivery signals, not your personality or psychological state.' : '이 점수는 관찰 가능한 말하기 신호이며 성격이나 실제 심리 상태를 판단하지 않습니다.'}</small></div>
            </section>
          )}
          {hasMeasuredVoice && (
            <section className="silence-analysis">
              <div className="section-title"><span>⏱</span><div><b>{language === 'en' ? 'Pause analysis' : '침묵 유형 분석'}</b><small>{language === 'en' ? 'Natural thinking time is separated from pauses that may weaken delivery.' : '자연스러운 생각 시간과 전달력을 낮출 수 있는 침묵을 구분했습니다.'}</small></div></div>
              <div className="silence-grid">
                <article className="natural"><span>🙂</span><div><b>{language === 'en' ? 'Natural thinking pauses' : '생각하는 침묵'}</b><strong>{displayEvaluation.metrics.thinkingPauses}{language === 'en' ? '' : '회'}</strong><small>{language === 'en' ? '2–3 seconds · natural' : '2~3초 · 자연스러움'}</small></div></article>
                <article className="long"><span>⏳</span><div><b>{language === 'en' ? 'Long pauses' : '너무 긴 침묵'}</b><strong>{displayEvaluation.metrics.longPauses}{language === 'en' ? '' : '회'}</strong><small>{language === 'en' ? '5+ seconds · may sound hesitant' : '5초 이상 · 망설임으로 들릴 수 있음'}</small></div></article>
                <article className="breaks"><span>〰</span><div><b>{language === 'en' ? 'Mid-speech breaks' : '말 중간 끊김'}</b><strong>{displayEvaluation.metrics.midSpeechBreaks}{language === 'en' ? '' : '회'}</strong><small>{language === 'en' ? 'Frequent breaks may reduce clarity' : '반복되면 전달력이 낮아질 수 있음'}</small></div></article>
              </div>
            </section>
          )}
          {hasMeasuredVoice && (
            <section className="rhythm-card">
              <div className="rhythm-score"><small>{language === 'en' ? 'PRESENTATION RHYTHM' : '발표 리듬'}</small><strong>{hasSufficientVoiceSample ? rhythmScore : '—'}</strong><span>{hasSufficientVoiceSample ? '/ 100' : (language === 'en' ? 'Insufficient data' : '측정 부족')}</span></div>
              <div className="rhythm-detail"><b>{hasSufficientVoiceSample ? (language === 'en' ? 'Rhythm matters more than speaking at one constant speed.' : '일정한 속도보다 핵심에 맞춰 자연스럽게 조절하는 리듬이 중요해요.') : (language === 'en' ? 'Answer each question for at least 15 seconds to measure rhythm reliably.' : '리듬을 정확히 측정하려면 질문마다 최소 15초 이상 답해 주세요.')}</b><div>{hasSufficientVoiceSample ? rhythmPhases.map((phase) => <span className={phase.status} key={phase.phase}>{phase.status === 'good' ? '✔' : '△'} {phase.label}</span>) : <span className="caution">△ {language === 'en' ? 'Not enough speaking data' : '답변 분량 부족'}</span>}</div><small>{language === 'en' ? 'Based on changes in pace, natural pauses, long silences, and mid-speech breaks.' : '답변별 속도 변화, 자연스러운 멈춤, 긴 침묵과 중간 끊김을 함께 반영했습니다.'}</small></div>
            </section>
          )}
          {audienceScores && (
            <section className="audience-perspective">
              <div className="section-title"><span>🧠</span><div><b>{language === 'en' ? 'How it sounds to the audience' : '청중 입장에서 들리는 느낌'}</b><small>{language === 'en' ? 'An estimate from the perspective of someone hearing this for the first time.' : '이 내용을 처음 듣는 사람의 관점에서 분석했습니다.'}</small></div></div>
              <div className="audience-score-grid">
                {[
                  [language === 'en' ? 'Easy to understand' : '이해하기 쉬움', audienceScores.clarity],
                  [language === 'en' ? 'Trust' : '신뢰감', audienceScores.trust],
                  [language === 'en' ? 'Confidence' : '자신감', audienceScores.confidence],
                  [language === 'en' ? 'Empathy' : '공감도', audienceScores.empathy],
                  [language === 'en' ? 'Memorability' : '기억에 남는 정도', audienceScores.memorability],
                ].map(([label, score]) => (
                  <div key={String(label)}><b>{label}</b><span aria-label={`${score} / 5`}>{'★'.repeat(Number(score))}<i>{'☆'.repeat(5 - Number(score))}</i><small>{score}/5</small></span></div>
                ))}
              </div>
            </section>
          )}
          {displayEvaluation.voiceNotice && <p className="voice-evaluation-notice">🎙️ {displayEvaluation.voiceNotice}</p>}
          {voiceAnswers.some(Boolean) && (
            <section className="result-stt-review" data-testid="result-stt-correction-panel">
              <div className="section-title"><span>🎤</span><div><b>{language === 'en' ? 'STT review · speaking habits' : '질문별 STT 교정 · 말버릇 분석'}</b><small>{language === 'en' ? 'Review what the AI heard for each answer.' : '어느 질문에서 어떤 표현이 인식됐는지 답변별로 확인해 보세요.'}</small></div></div>
              <div className="result-stt-question-list">
                {questions.slice(0, answers.length).map((question, index) => {
                  if (!voiceAnswers[index]) return null
                  const review = speechAnswerReviews[index] ?? { transcript: answers[index] ?? '', corrections: [] }
                  const corrections = review.corrections.filter((correction) => !/핵심부터 말하기|lead with the main point/i.test(correction.after))
                  const suggested = corrections.reduce((text, correction) => text.split(correction.before).join(correction.after), review.transcript)
                  const habits = countSpeechHabits(review.transcript)
                  const spokenSeconds = voiceDurations[index] ?? 0
                  const durationTone = spokenSeconds < 15 ? 'short' : spokenSeconds <= 30 ? 'good' : 'long'
                  const durationLabel = language === 'en'
                    ? spokenSeconds < 15 ? 'too short' : spokenSeconds <= 30 ? 'appropriate' : 'long'
                    : spokenSeconds < 15 ? '짧음' : spokenSeconds <= 30 ? '적절' : '김'
                  const exampleOpening = modelAnswers[index].split(/(?<=[.!?])\s+/)[0]
                  return (
                    <article className="result-stt-question-card" data-testid={`result-stt-question-${index}`} key={`${question}-${index}`}>
                      <header>
                        <div><span>{language === 'en' ? `Question ${index + 1}` : `질문 ${index + 1}`}</span><em className={durationTone}>{durationTone === 'good' ? '🟢' : durationTone === 'short' ? '🟡' : '🟠'} {spokenSeconds.toFixed(1)}{language === 'en' ? 's' : '초'} ({durationLabel})</em></div>
                        <b>{question}</b>
                      </header>
                      <div className="speech-sentence-comparison">
                        <div><small>{language === 'en' ? '🎤 AI heard' : '🎤 AI가 들은 내용'}</small><p>{review.transcript || (language === 'en' ? 'No recognized voice text.' : '인식된 음성 문장이 없습니다.')}</p></div>
                        <div><small>{language === 'en' ? '💡 Suggested correction' : '💡 AI 추천 교정'}</small><p>{suggested || review.transcript || (language === 'en' ? 'No correction available.' : '추천 교정이 없습니다.')}</p></div>
                      </div>
                      {corrections.length > 0 ? (
                        <div className="speech-correction-table">
                          <div className="correction-header"><span>{language === 'en' ? '🔎 Recognized word' : '🔎 변경 전 단어'}</span><span>{language === 'en' ? 'Suggested word' : '변경된 단어'}</span></div>
                          {corrections.map((correction, correctionIndex) => <div className="correction-row" key={`${correction.before}-${correction.after}-${correctionIndex}`}><span>{correction.before}</span><b>✅ {correction.after}</b></div>)}
                        </div>
                      ) : <p className="speech-empty-result">🔎 {language === 'en' ? 'Changed words: none' : '변경된 단어: 없음'}</p>}
                      <div className="speech-habit-analysis">
                        <b>{language === 'en' ? '💬 Speaking habits' : '💬 말버릇 분석'}</b>
                        {habits.length > 0
                          ? <div>{habits.map(([habit, count]) => <span key={habit}>{habit} <strong>{count}{language === 'en' ? '×' : '회'}</strong></span>)}</div>
                          : <small>{language === 'en' ? 'Speaking habits: none detected' : '말버릇: 감지된 표현 없음'}</small>}
                        <p>{language === 'en' ? 'Try pausing for one second instead of using a filler, then lead with your main point.' : '“음…” 같은 습관어 대신 1초 생각한 후 바로 핵심부터 말해 보세요.'}</p>
                      </div>
                      <div className={`stt-answer-coaching ${echoAnswers[index] ? 'echo' : 'direct'}`}>
                        <div><b>{echoAnswers[index] ? '❌' : '✅'} {language === 'en' ? 'Quick evaluation' : '간단 평가'}</b><p>{echoAnswers[index] ? (language === 'en' ? 'You repeated the question instead of answering it.' : '질문을 반복했으며 직접적인 답변이 부족합니다.') : (language === 'en' ? 'Your response was structurally distinct from the question.' : '질문을 그대로 반복하지 않고 별도의 답변을 말했습니다.')}</p></div>
                        <div><b>✅ {language === 'en' ? 'A stronger opening' : '이렇게 말하면 좋아요'}</b><blockquote>“{exampleOpening}”</blockquote></div>
                      </div>
                    </article>
                  )
                })}
              </div>
              <small className="stt-notice">{language === 'en' ? '※ The recognized answer was not changed automatically.' : '※ 인식된 답변은 자동으로 수정되지 않았습니다.'}</small>
            </section>
          )}
          <div className="result-grid">
            <article className="result-card good"><span>✓</span><div><h3>{language === 'en' ? 'Strengths' : '잘한 점'}</h3><ul>{displayEvaluation.strengths.map((item) => <li key={item}>{item}</li>)}</ul></div></article>
            <article className="result-card improve"><span>↗</span><div><h3>{language === 'en' ? 'Areas to improve' : '개선할 점'}</h3><ul>{displayEvaluation.improvements.map((item) => <li key={item}>{item}</li>)}</ul></div></article>
          </div>
          <div className="improvement-prediction"><span>💡</span><div><b>{language === 'en' ? 'Estimated improvement' : '예상 향상 점수'}</b><p>{displayEvaluation.estimatedImprovement}</p></div></div>
          <section className="retry-priorities">
            <div className="section-title"><span>↻</span><div><b>{language === 'en' ? 'Top 3 AI-recommended practice goals' : 'AI 추천 개선 연습 TOP 3'}</b><small>{language === 'en' ? 'Focus on just these three points in your next session.' : '다음 연습에서는 이 세 가지에만 집중해 보세요.'}</small></div></div>
            <ol>{retryPriorities.map((priority, index) => <li key={priority.metric}><span>{index + 1}</span><div><b><i>{priority.score <= 7 ? '🟠' : priority.score <= 12 ? '🟢' : '🔵'}</i>{priority.label}</b><small>{language === 'en' ? `${priority.metric} (${priority.score}/20) was ${index === 0 ? 'the lowest score' : 'one of the lower scores'}. ${priority.guide}` : `${priority.metric} 점수(${priority.score}/20)가 ${index === 0 ? '가장 낮았습니다' : '낮았습니다'}. ${priority.guide}`}</small></div></li>)}</ol>
          </section>
          <section className="answer-review">
            <div className="section-title"><span>✦</span><div><b>{language === 'en' ? 'Compare your answers' : '답변별 AI 모범답안'}</b><small>{language === 'en' ? 'Open each question to compare your answer with an AI example.' : '질문을 열어 내 답변과 문서 기반 예시를 비교해 보세요.'}</small></div></div>
            <div className="answer-review-list">
              {questions.slice(0, answers.length).map((question, index) => (
                <details key={`${question}-${index}`}>
                  <summary><span>Q{index + 1}</span><b>{question}</b><em>{language === 'en' ? 'View example answer' : '좋은 답변 예시'}</em></summary>
                  <div className="answer-comparison">
                    <article><small>{language === 'en' ? 'MY ANSWER' : '내 답변'}</small><p>{answers[index] || (language === 'en' ? 'No answer' : '답변 없음')}</p></article>
                    <article className="model-answer"><small>{language === 'en' ? 'AI EXAMPLE' : 'AI 모범답안'}</small><p>{modelAnswers[index]}</p></article>
                  </div>
                  {speechAnswerReviews[index] && (() => {
                    const review = speechAnswerReviews[index]!
                    const corrections = review.corrections.filter((correction) => !/핵심부터 말하기|lead with the main point/i.test(correction.after))
                    const suggested = corrections.reduce((text, correction) => text.split(correction.before).join(correction.after), review.transcript)
                    const habits = countSpeechHabits(review.transcript)
                    return (
                      <section className="answer-stt-review" data-testid={`answer-stt-review-${index}`}>
                        <b>{language === 'en' ? 'Speech recognition review' : '음성 인식 상세 분석'}</b>
                        <div className="speech-sentence-comparison">
                          <article><small>{language === 'en' ? 'WHAT AI HEARD' : 'AI가 들은 내용'}</small><p>{review.transcript}</p></article>
                          <article><small>{language === 'en' ? 'SUGGESTED CORRECTION' : 'AI 추천 교정'}</small><p>{suggested}</p></article>
                        </div>
                        {corrections.length > 0 && <div className="speech-correction-table"><b>{language === 'en' ? 'Changed words' : '변경된 단어'}</b>{corrections.map((correction, correctionIndex) => <p key={`${correction.before}-${correction.after}-${correctionIndex}`}><span>{correction.before}</span><i>→</i><strong>{correction.after}</strong></p>)}</div>}
                        <div className="speech-habit-analysis">
                          <b>{language === 'en' ? 'Speaking habits' : '말버릇 분석'}</b>
                          {habits.length > 0
                            ? <div>{habits.map(([word, count]) => <span key={word}>{word} ({count}{language === 'en' ? '' : '회'})</span>)}</div>
                            : <small>{language === 'en' ? 'No filler words were detected in this answer.' : '이 답변에서는 습관어가 감지되지 않았습니다.'}</small>}
                          <p>{language === 'en' ? 'Pause for one second instead of using a filler, then lead with your main point.' : '“음…” 같은 습관어 대신 1초 생각한 뒤 핵심부터 말해 보세요.'}</p>
                        </div>
                        <small className="stt-notice">{language === 'en' ? 'The recognized answer was not changed automatically.' : '인식된 답변은 자동으로 수정되지 않았습니다.'}</small>
                      </section>
                    )
                  })()}
                </details>
              ))}
            </div>
          </section>
          <section className="predicted-questions">
            <div className="section-title"><span>🥇</span><div><b>{language === 'en' ? 'Predicted evaluator questions' : '예상 심사위원 질문'}</b><small>{language === 'en' ? 'Questions likely to follow in a real evaluation.' : '실제 심사에서 이어질 가능성이 높은 질문입니다.'}</small></div></div>
            <div className="predicted-question-list">
              {predictedQuestions.slice(0, 4).map((item, index) => (
                <article key={`${item.question}-${index}`}>
                  <div className="predicted-question-heading"><span>{String(index + 1).padStart(2, '0')}</span><b>{item.question}</b></div>
                  <div className="predicted-question-actions">
                    <details><summary>{language === 'en' ? 'View example answer' : '좋은 답변 예시'}</summary><p>{item.modelAnswer}</p></details>
                    <button onClick={() => practicePredictedQuestion(item.question)}>{language === 'en' ? 'Practice this question' : '이 질문으로 재연습'} <b>→</b></button>
                  </div>
                </article>
              ))}
            </div>
          </section>
          <div className="result-actions"><button className="secondary" onClick={() => setStage('setup')}>{language === 'en' ? 'Create new practice' : '새 연습 만들기'}</button><button className="primary" onClick={restart}>{language === 'en' ? 'Practice again with same settings' : '같은 조건으로 재연습'} <b>→</b></button></div>
        </section>
      )}
    </main>
  )
}

export default App
