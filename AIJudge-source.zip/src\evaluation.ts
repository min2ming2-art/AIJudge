export interface EvaluationResult {
  score: number
  title: string
  headline: string
  summary: string
  strengths: string[]
  improvements: string[]
  estimatedImprovement: string
  verdict?: 'high' | 'potential' | 'difficult'
  modelAnswers?: string[]
  retryPriorities?: string[]
  predictedQuestions?: Array<{ question: string; modelAnswer: string }>
  confidenceSummary?: string
  rhythmScore?: number
  rhythmPhases?: Array<{ phase: 'opening' | 'middle' | 'closing'; label: string; status: 'good' | 'caution' }>
  audienceScores?: {
    clarity: number
    trust: number
    confidence: number
    empathy: number
    memorability: number
  }
  voiceNotice?: string
  metrics: {
    averageLength: number
    relevance: number
    evidence: number
    understanding: number
    evidenceScore: number
    logic: number
    delivery: number
    persuasion: number
    responseLatency: number
    speakingPace: number
    confidenceScore: number
    thinkingPauses: number
    longPauses: number
    midSpeechBreaks: number
    fillerCount: number
    voiceSampleSufficient: number
  }
}

export interface SilenceStats {
  thinkingPauses: number
  longPauses: number
  midSpeechBreaks: number
}

const stopWords = new Set([
  '대해', '대한', '어떤', '무엇', '어떻게', '설명', '주세요', '문서', '자료', '핵심', '관련', '생각', '있는', '있나요', '본인', '가장',
  '말씀', '보세요', '답하시겠습니까', '무엇입니까', '계획', '내용', '질문', '기존',
  'about', 'what', 'which', 'how', 'please', 'explain', 'describe', 'question', 'answer', 'main', 'most', 'would', 'could', 'should',
])

const tokenize = (text: string) =>
  (text.toLowerCase().match(/[가-힣a-z0-9]{2,}/g) ?? [])
    .map((word) => word.replace(/(으로|에서|에게|보다|처럼|만큼|이라는|라고|에는|에도|은|는|이|가|을|를|의|에|도|와|과|로)$/u, ''))
    .filter((word) => word.length >= 2)
    .filter((word) => !stopWords.has(word) && !/^\d+$/.test(word))

const unique = <T,>(items: T[]) => [...new Set(items)]
const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value))

const matchesQuestionIntent = (question: string, answer: string) => {
  const intents = [
    { question: /차별|기존 대안|기존 방식/, answer: /차별|기존|다르|개선|전체|비교|장점/ },
    { question: /고객|핵심 문제/, answer: /고객|사용자|골퍼|불편|문제|어려움|허리|반복/ },
    { question: /자원|시제품|제작/, answer: /비용|제작비|집행비|생산비|예산|자금|인력|시간|시설|장비/ },
    { question: /투자 가치|한 문장/, answer: /제품|서비스|기기|해소|해결|시장|수익|가치|고객/ },
    { question: /효과|검증/, answer: /수치|시험|테스트|설문|반응|결과|측정|비교/ },
    { question: /difference|alternative/i, answer: /different|existing|improv|compar|advantage/i },
    { question: /customer|core problem/i, answer: /customer|user|problem|pain|difficulty|need/i },
    { question: /resource|prototype/i, answer: /cost|budget|fund|people|team|time|facility|equipment/i },
    { question: /investment value|one sentence/i, answer: /product|service|solve|market|revenue|value|customer/i },
    { question: /impact|validate|evidence/i, answer: /number|test|survey|response|result|measure|compar/i },
  ]
  const intent = intents.find((item) => item.question.test(question))
  return intent ? intent.answer.test(answer) : false
}

export function evaluateAnswers(
  questions: string[],
  answers: string[],
  documentText: string,
  voiceAnswers: boolean[] = [],
  language: 'ko' | 'en' = 'ko',
  voiceDurations: number[] = [],
  responseLatencies: number[] = [],
  silenceStats: SilenceStats[] = [],
): EvaluationResult {
  const strengths: string[] = []
  const improvements: string[] = []
  let relevanceTotal = 0
  let evidenceTotal = 0
  let logicTotal = 0
  let conclusionCount = 0
  let fillerCount = 0
  let totalLength = 0
  let factualIssueCount = 0
  let offTopicCount = 0

  const answerScores = questions.map((question, index) => {
    const answer = (answers[index] ?? '').trim()
    const compactLength = answer.replace(/\s/g, '').length
    totalLength += compactLength
    fillerCount += (answer.match(/(?:^|[\s,.!?])(?:음+|어+|아+|저|저기|그게|뭐랄까)(?=$|[\s,.!?])/g) ?? []).length

    if (!answer) {
      improvements.push(`${index + 1}번 질문에 답변하지 않았어요. 짧게라도 핵심 의견을 말해 보세요.`)
      return 5
    }

    let score = 48
    if (compactLength < 10) {
      score -= 32
      improvements.push('한두 단어로 끝난 답변이 있어요. 결론 뒤에 이유를 한 문장 이상 덧붙여 보세요.')
    } else if (compactLength < 30) {
      score -= 18
      improvements.push('답변이 전반적으로 짧아요. 상황과 행동, 결과를 함께 설명해 보세요.')
    } else if (compactLength < 60) {
      score -= 5
    } else if (compactLength <= 260) {
      score += 9
      strengths.push('충분한 길이로 생각을 구체적으로 전달했어요.')
    } else if (compactLength > 500) {
      score -= 8
      improvements.push('답변이 다소 길어요. 결론과 핵심 근거를 먼저 말해 보세요.')
    }

    const unknownCount = (answer.match(/모르겠|잘 모르|생각해본 적 없|답하기 어렵|I don't know|not sure|never thought about|hard to answer/gi) ?? []).length
    if (unknownCount > 0) {
      score -= Math.min(30, unknownCount * 14)
      improvements.push('“모르겠습니다”로 끝내기보다 아는 범위와 추론 과정을 함께 말해 보세요.')
    }

    const impossibleCounts = [...answer.matchAll(/(\d+)\s*명\s*중\s*(\d+)\s*명/gu)]
      .filter((match) => Number(match[2]) > Number(match[1]))
    if (impossibleCounts.length > 0) {
      factualIssueCount += impossibleCounts.length
      score -= 24
      improvements.push(`응답자 수가 전체 인원보다 큰 “${impossibleCounts[0][0]}”은 성립하지 않아요. 문서의 원래 수치를 다시 확인해 주세요.`)
    }

    const domainTerms = language === 'en'
      ? ['table tennis', 'soccer', 'baseball', 'cooking', 'restaurant']
      : ['탁구', '축구', '야구', '요리', '음식', '식당']
    const unrelatedTerms = domainTerms.filter((term) => answer.toLowerCase().includes(term) && !documentText.toLowerCase().includes(term))
    if (unrelatedTerms.length > 0) {
      offTopicCount += unrelatedTerms.length
      score -= 24
      improvements.push(`문서와 관련 없는 “${unrelatedTerms[0]}” 표현이 포함됐어요. 질문의 주제와 문서 내용을 다시 확인해 주세요.`)
    }

    const questionKeywords = unique(tokenize(question)).slice(0, 6)
    const answerKeywords = unique(tokenize(answer))
    const matchedKeywords = questionKeywords.filter((keyword) =>
      answerKeywords.some((answerKeyword) => answerKeyword.includes(keyword) || keyword.includes(answerKeyword)),
    )
    const lexicalRelevance = questionKeywords.length ? matchedKeywords.length / questionKeywords.length : 0
    const relevanceRatio = Math.max(lexicalRelevance, matchesQuestionIntent(question, answer) ? 0.65 : 0)
    relevanceTotal += relevanceRatio
    if (relevanceRatio < 0.15) {
      score -= 18
      improvements.push('일부 답변에서 질문의 핵심이 충분히 드러나지 않았어요. 질문의 표현을 받아서 답을 시작해 보세요.')
    } else if (relevanceRatio >= 0.35) {
      score += 10
      strengths.push('질문의 핵심어를 활용해 관련성 높은 답변을 했어요.')
    } else {
      score += 3
    }

    const evidenceSignals = [
      /예를 들어|예시|사례|경험|for example|for instance|case|experience/i, /왜냐하면|때문에|이유는|근거|because|reason|evidence/i, /\d+(?:[.,]\d+)?\s*(?:%|퍼센트|명|회|개월|년|배|건|홀|원|만원|억원|people|times|months?|years?)/i,
      /결과적으로|그 결과|성과|개선|증가|감소|as a result|outcome|improved|increased|decreased/i, /첫째|둘째|우선|다음으로|따라서|first|second|next|therefore/i,
    ].filter((pattern) => pattern.test(answer)).length
    evidenceTotal += evidenceSignals
    const logicSignals = [
      /왜냐하면|때문에|이유는|because|reason/i, /첫째|둘째|우선|다음으로|first|second|next/i, /따라서|결과적으로|그러므로|therefore|as a result/i, /반면|하지만|다만|however|on the other hand/i,
    ].filter((pattern) => pattern.test(answer)).length
    logicTotal += logicSignals
    score += Math.min(20, evidenceSignals * 5)
    if (evidenceSignals >= 2) strengths.push('이유와 사례를 사용해 주장을 설득력 있게 뒷받침했어요.')
    if (compactLength >= 45 && evidenceSignals === 0) improvements.push('주장에 구체적인 경험, 수치 또는 사례를 하나 추가해 보세요.')

    if (/저는|제 생각|결론|핵심은|I believe|I think|in conclusion|the key (?:point )?is/i.test(answer)) {
      conclusionCount += 1
      score += 4
      strengths.push('자신의 관점과 결론을 분명하게 표현했어요.')
    }

    return clamp(score, 5, 100)
  })

  const ruleAverage = Math.round(answerScores.reduce((sum, item) => sum + item, 0) / Math.max(questions.length, 1))
  const averageLength = Math.round(totalLength / Math.max(answers.filter(Boolean).length, 1))
  const relevance = Math.round((relevanceTotal / Math.max(questions.length, 1)) * 100)
  const evidence = Math.min(100, Math.round((evidenceTotal / Math.max(questions.length, 1)) * 35))
  const completedRatio = answers.filter((answer) => answer.trim()).length / Math.max(questions.length, 1)
  const averageLogicSignals = logicTotal / Math.max(answers.filter(Boolean).length, 1)
  const issuePenalty = factualIssueCount * 3 + offTopicCount * 4
  const understanding = Math.round(clamp((6 + relevance * 0.14 - issuePenalty) * completedRatio, 0, 20))
  const evidenceScore = Math.round(clamp((6 + evidence * 0.14 - factualIssueCount * 4 - offTopicCount * 2) * completedRatio, 0, 20))
  const logic = Math.round(clamp((7 + averageLogicSignals * 4 + (averageLength >= 35 ? 2 : 0) + relevance * 0.04 - issuePenalty) * completedRatio, 0, 20))
  // A smooth pace alone is not enough for high delivery marks. Very short
  // answers cannot demonstrate a complete conclusion-and-reason structure.
  const deliveryBase = averageLength < 15 ? 5 : averageLength < 30 ? 8 : averageLength < 50 ? 12 : averageLength <= 260 ? 17 : averageLength <= 500 ? 14 : 9
  const delivery = Math.round(clamp((deliveryBase - Math.min(5, fillerCount)) * completedRatio, 0, 20))
  const persuasion = Math.round(clamp(
    ((understanding + evidenceScore + logic) / 4 + ruleAverage / 20 + conclusionCount - issuePenalty) * completedRatio,
    0,
    20,
  ))
  const score = understanding + evidenceScore + logic + delivery + persuasion
  if (relevance < 25) {
    const contradictoryStrength = strengths.indexOf('질문의 핵심어를 활용해 관련성 높은 답변을 했어요.')
    if (contradictoryStrength >= 0) strengths.splice(contradictoryStrength, 1)
  }
  if (averageLength < 60) {
    const lengthStrength = strengths.indexOf('충분한 길이로 생각을 구체적으로 전달했어요.')
    if (lengthStrength >= 0) strengths.splice(lengthStrength, 1)
  }
  if (fillerCount >= 2) improvements.unshift(`“음”, “저”, “그게” 같은 습관어가 ${fillerCount}회 감지됐어요. 답변 전 1초 멈춘 뒤 핵심부터 말해 보세요.`)

  if (strengths.length === 0) strengths.push('연습을 끝까지 진행하며 답변 개선의 출발점을 만들었어요.')
  if (improvements.length === 0) improvements.push('좋은 답변이에요. 다음에는 핵심 메시지를 더 짧고 강하게 정리해 보세요.')

  const weakestMetric = [
    { value: understanding, title: '질문의 핵심을 먼저 정확히 짚는 연습이 필요합니다' },
    { value: evidenceScore, title: '핵심은 이해했지만 문서 근거가 부족했습니다' },
    { value: logic, title: '결론과 이유를 연결하는 연습이 필요합니다' },
    { value: delivery, title: '답변을 완결된 문장으로 전달하는 연습이 필요합니다' },
    { value: persuasion, title: '주장을 뒷받침할 사례와 근거가 필요합니다' },
  ].sort((a, b) => a.value - b.value)[0]
  const title = score >= 85
    ? '근거와 논리가 고르게 갖춰진 설득력 있는 답변입니다'
    : score >= 70
      ? '핵심은 잘 전달했으며 근거를 조금 더 보강하면 좋습니다'
      : weakestMetric.title
  const headline = score >= 85 ? '근거와 핵심이 모두 돋보였습니다.' : score >= 70 ? '핵심은 분명했습니다.' : score >= 50 ? '의도는 전달됐지만 근거가 부족합니다.' : '질문에 맞는 결론과 이유가 필요합니다.'
  const summary = `평균 답변 길이는 ${averageLength}자이며, 질문 핵심어 관련성은 ${relevance}%입니다. ${evidence >= 60 ? '근거와 사례를 적극적으로 활용했습니다.' : '구체적인 근거와 사례를 보강하면 점수가 크게 좋아집니다.'}`
  const estimatedImprovement = averageLength < 30
    ? '답변에 상황과 결과를 한 문장씩 추가하면 약 +12점 향상될 수 있습니다.'
    : relevance < 35
      ? '질문의 핵심 표현을 답변 첫 문장에 포함하면 약 +8점 향상될 수 있습니다.'
      : evidence < 60
        ? '구체적인 사례나 수치 근거를 1개 추가하면 약 +12점 향상될 수 있습니다.'
        : '핵심 결론을 먼저 말하면 약 +5점 향상될 수 있습니다.'
  const voiceAnswerCount = voiceAnswers.filter(Boolean).length
  const voiceNotice = voiceAnswerCount > 0
    ? `${voiceAnswerCount}개 음성 답변을 분석했습니다. 음성 인식 문장이 실제 발화와 다르면 점수도 달라질 수 있으니 제출 전 받아쓰기를 확인해 주세요.`
    : undefined

  if (language === 'en') {
    const translations = new Map([
      ['한두 단어로 끝난 답변이 있어요. 결론 뒤에 이유를 한 문장 이상 덧붙여 보세요.', 'Some answers ended after only a few words. Add at least one sentence explaining your reason.'],
      ['답변이 전반적으로 짧아요. 상황과 행동, 결과를 함께 설명해 보세요.', 'Your answers were generally short. Explain the situation, action, and result together.'],
      ['충분한 길이로 생각을 구체적으로 전달했어요.', 'You communicated your ideas with enough specific detail.'],
      ['답변이 다소 길어요. 결론과 핵심 근거를 먼저 말해 보세요.', 'Some answers were long. Lead with your conclusion and strongest evidence.'],
      ['“모르겠습니다”로 끝내기보다 아는 범위와 추론 과정을 함께 말해 보세요.', 'Instead of stopping at “I don’t know,” explain what you know and how you would reason about it.'],
      ['일부 답변에서 질문의 핵심이 충분히 드러나지 않았어요. 질문의 표현을 받아서 답을 시작해 보세요.', 'Some answers did not address the core of the question clearly. Begin by directly reflecting the question.'],
      ['질문의 핵심어를 활용해 관련성 높은 답변을 했어요.', 'You used the key terms from the questions and stayed relevant.'],
      ['이유와 사례를 사용해 주장을 설득력 있게 뒷받침했어요.', 'You supported your claims persuasively with reasons and examples.'],
      ['주장에 구체적인 경험, 수치 또는 사례를 하나 추가해 보세요.', 'Add one concrete experience, number, or example to support your claim.'],
      ['자신의 관점과 결론을 분명하게 표현했어요.', 'You expressed your perspective and conclusion clearly.'],
      ['연습을 끝까지 진행하며 답변 개선의 출발점을 만들었어요.', 'You completed the practice and established a clear starting point for improvement.'],
      ['좋은 답변이에요. 다음에는 핵심 메시지를 더 짧고 강하게 정리해 보세요.', 'Good answers. Next time, make the central message shorter and stronger.'],
    ])
    const translate = (item: string) => {
      const unanswered = item.match(/^(\d+)번 질문에 답변하지 않았어요/)
      if (unanswered) return `Question ${unanswered[1]} was not answered. State your main view, even briefly.`
      if (item.includes('같은 습관어가')) return `Filler words were detected ${fillerCount} times. Pause for one second, then begin with your main point.`
      return translations.get(item) ?? item
    }
    strengths.splice(0, strengths.length, ...strengths.map(translate))
    improvements.splice(0, improvements.length, ...improvements.map(translate))
  }

  const localizedTitle = language === 'en'
    ? score >= 85 ? 'Highly persuasive answers' : score >= 70 ? 'A strong overall flow' : score >= 50 ? 'Make the main point clearer' : 'Rebuild the structure of your answers'
    : title
  const localizedHeadline = language === 'en'
    ? score >= 85 ? 'Both your evidence and key points stood out.' : score >= 70 ? 'Your main points were clear.' : score >= 50 ? 'Your intent was clear, but the evidence was limited.' : 'Your answers need a conclusion and reasons that directly address the question.'
    : headline
  const localizedSummary = language === 'en'
    ? `Your average answer length was ${averageLength} characters, with ${relevance}% relevance to the questions' key terms. ${evidence >= 60 ? 'You made active use of evidence and examples.' : 'Adding concrete evidence and examples would improve your score significantly.'}`
    : summary
  const localizedImprovement = language === 'en'
    ? averageLength < 30 ? 'Adding one sentence each for the situation and result could improve your score by about 12 points.'
      : relevance < 35 ? 'Using the question’s key phrase in your opening sentence could improve your score by about 8 points.'
        : evidence < 60 ? 'Adding one concrete example or numerical fact could improve your score by about 12 points.'
          : 'Leading with your conclusion could improve your score by about 5 points.'
    : estimatedImprovement
  const localizedVoiceNotice = language === 'en' && voiceAnswerCount > 0
    ? `${voiceAnswerCount} voice answer(s) were analyzed. Check the transcript before submitting because recognition errors can affect the score.`
    : voiceNotice
  const voiceText = answers.filter((_, index) => voiceAnswers[index]).join(' ')
  const measurableUnits = language === 'en'
    ? (voiceText.match(/[A-Za-z0-9'-]+/g) ?? []).length
    : voiceText.replace(/\s/g, '').length
  const totalVoiceSeconds = voiceDurations.reduce((sum, seconds, index) => sum + (voiceAnswers[index] ? seconds : 0), 0)
  const hasMeasuredVoice = voiceAnswerCount > 0 && totalVoiceSeconds > 0
  const averageVoiceUnits = voiceAnswerCount > 0 ? measurableUnits / voiceAnswerCount : 0
  const voiceSampleSufficient = hasMeasuredVoice
    && totalVoiceSeconds >= 8
    && averageVoiceUnits >= (language === 'en' ? 12 : 25)
  const speakingPace = totalVoiceSeconds > 0 ? Math.round(measurableUnits / totalVoiceSeconds * 60) : 0
  const measuredLatencies = responseLatencies.filter((seconds, index) => voiceAnswers[index] && seconds > 0)
  const responseLatency = measuredLatencies.length
    ? Math.round(measuredLatencies.reduce((sum, seconds) => sum + seconds, 0) / measuredLatencies.length * 10) / 10
    : 0
  const observableFillers = (voiceText.match(/(?:^|[\s,.!?])(?:음+|어+|저|그게|그러니까|um+|uh+|like|you know)(?=$|[\s,.!?])/gi) ?? []).length
  const idealPace = speakingPace === 0 || (language === 'en' ? speakingPace >= 100 && speakingPace <= 175 : speakingPace >= 220 && speakingPace <= 460)
  const pacePenalty = idealPace ? 0 : speakingPace > 0 ? 10 : 4
  const latencyPenalty = responseLatency <= 0 ? 4 : responseLatency <= 2.5 ? 0 : responseLatency <= 4 ? 5 : Math.min(18, Math.round(responseLatency * 2.5))
  const fillerPenalty = Math.min(24, observableFillers * 3)
  const thinkingPauses = silenceStats.reduce((sum, stats, index) => sum + (voiceAnswers[index] ? stats.thinkingPauses : 0), 0)
  const longPauses = silenceStats.reduce((sum, stats, index) => sum + (voiceAnswers[index] ? stats.longPauses : 0), 0)
  const midSpeechBreaks = silenceStats.reduce((sum, stats, index) => sum + (voiceAnswers[index] ? stats.midSpeechBreaks : 0), 0)
  const silencePenalty = Math.min(20, longPauses * 6 + Math.max(0, midSpeechBreaks - thinkingPauses - longPauses) * 2)
  const confidenceScore = voiceSampleSufficient
    ? Math.round(clamp(88 - pacePenalty - latencyPenalty - fillerPenalty - silencePenalty, 20, 100))
    : 0
  const answerPaces = answers.map((item, index) => {
    if (!voiceAnswers[index] || !voiceDurations[index]) return 0
    const units = language === 'en' ? (item.match(/[A-Za-z0-9'-]+/g) ?? []).length : item.replace(/\s/g, '').length
    return Math.round(units / voiceDurations[index] * 60)
  }).filter(Boolean)
  const paceAverage = answerPaces.length ? answerPaces.reduce((sum, pace) => sum + pace, 0) / answerPaces.length : 0
  const paceVariation = answerPaces.length > 1 && paceAverage > 0
    ? Math.sqrt(answerPaces.reduce((sum, pace) => sum + (pace - paceAverage) ** 2, 0) / answerPaces.length) / paceAverage
    : 0
  const variationPenalty = paceVariation <= 0.28 ? 0 : Math.min(18, Math.round((paceVariation - 0.28) * 35))
  const rhythmScore = voiceSampleSufficient
    ? Math.round(clamp(94 - pacePenalty - variationPenalty - longPauses * 5 - Math.max(0, midSpeechBreaks - thinkingPauses) * 2, 20, 100))
    : 0
  const phaseNames = language === 'en'
    ? { opening: 'Opening', middle: 'Middle', closing: 'Closing' }
    : { opening: '초반', middle: '중간', closing: '마무리' }
  const phaseKeys = ['opening', 'middle', 'closing'] as const
  const rhythmPhases = phaseKeys.map((phase, index) => {
    const paceIndex = answerPaces.length <= 1 ? 0 : Math.round(index * (answerPaces.length - 1) / 2)
    const pace = answerPaces[paceIndex] ?? 0
    const paceGood = pace > 0 && (language === 'en' ? pace >= 100 && pace <= 175 : pace >= 220 && pace <= 460)
    const label = language === 'en'
      ? pace === 0 ? `${phaseNames[phase]} not measured` : paceGood ? `${phaseNames[phase]} steady` : pace > (language === 'en' ? 175 : 460) ? `${phaseNames[phase]} slightly fast` : `${phaseNames[phase]} slightly slow`
      : pace === 0 ? `${phaseNames[phase]} 측정 부족` : paceGood ? phase === 'closing' ? '마무리 좋음' : `${phaseNames[phase]} 안정` : pace > 460 ? `${phaseNames[phase]} 조금 빠름` : `${phaseNames[phase]} 조금 느림`
    return { phase, label, status: paceGood ? 'good' as const : 'caution' as const }
  })
  const confidenceSummary = language === 'en'
    ? !voiceSampleSufficient
      ? 'The spoken answers were too short to evaluate confidence and presentation rhythm reliably. Try answering each question for at least 15 seconds.'
      : responseLatency > 4
      ? 'Your answer content was meaningful, but the long delay before speaking may have sounded hesitant.'
      : observableFillers >= 3
        ? 'Your main points were clear, but repeated filler words made your delivery sound less certain.'
        : 'You began naturally and delivered your answer with a steady, confident flow.'
    : !voiceSampleSufficient
      ? '음성 답변이 너무 짧아 자신감과 발표 리듬을 정확히 평가하기 어렵습니다. 질문마다 최소 15초 이상 답해 보세요.'
      : responseLatency > 4
      ? '답변 내용은 의미 있었지만 말하기 시작까지 시간이 길어 망설이는 인상으로 전달될 수 있어요.'
      : observableFillers >= 3
        ? '핵심은 분명했지만 반복된 습관어 때문에 확신이 조금 약하게 전달됐어요.'
        : '자연스럽게 답변을 시작하고 안정적인 흐름으로 자신감 있게 전달했어요.'
  const audienceScores = {
    clarity: Math.round(clamp(1 + understanding / 5, 1, 5)),
    trust: Math.round(clamp(1 + evidenceScore / 5, 1, 5)),
    confidence: hasMeasuredVoice
      ? Math.round(clamp(confidenceScore / 20, 1, 5))
      : Math.round(clamp((delivery + persuasion) / 8, 1, 5)),
    empathy: Math.round(clamp(1 + (relevance + Math.min(100, averageLength)) / 50, 1, 5)),
    memorability: Math.round(clamp(1 + persuasion / 5, 1, 5)),
  }

  return {
    score,
    title: localizedTitle,
    headline: localizedHeadline,
    summary: localizedSummary,
    strengths: unique(strengths).slice(0, 3),
    improvements: unique(improvements).slice(0, 3),
    estimatedImprovement: localizedImprovement,
    confidenceSummary,
    rhythmScore,
    rhythmPhases,
    audienceScores,
    voiceNotice: localizedVoiceNotice,
    metrics: { averageLength, relevance, evidence, understanding, evidenceScore, logic, delivery, persuasion, responseLatency, speakingPace, confidenceScore, thinkingPauses, longPauses, midSpeechBreaks, fillerCount: observableFillers, voiceSampleSufficient: voiceSampleSufficient ? 1 : 0 },
  }
}
