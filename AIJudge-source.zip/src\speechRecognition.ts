export interface SpeechRecognitionEventLike extends Event {
  resultIndex: number
  results: SpeechRecognitionResultList
}

export interface SpeechRecognitionErrorEventLike extends Event {
  error: string
}

export interface SpeechRecognitionLike {
  lang: string
  continuous: boolean
  interimResults: boolean
  maxAlternatives: number
  onresult: ((event: SpeechRecognitionEventLike) => void) | null
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null
  onend: (() => void) | null
  start(): void
  stop(): void
  abort(): void
}

type SpeechRecognitionConstructor = new () => SpeechRecognitionLike
type SpeechWindow = Window & typeof globalThis & {
  SpeechRecognition?: SpeechRecognitionConstructor
  webkitSpeechRecognition?: SpeechRecognitionConstructor
}

export function isSpeechRecognitionSupported() {
  const speechWindow = window as SpeechWindow
  return Boolean(speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition)
}

export function getSpeechRecognition() {
  const speechWindow = window as SpeechWindow
  const Recognition = speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition
  return Recognition ? new Recognition() : null
}

export function speechErrorMessage(error: string) {
  if (error === 'not-allowed' || error === 'service-not-allowed') return '마이크 사용 권한을 허용한 뒤 다시 시도해 주세요.'
  if (error === 'audio-capture') return '사용 가능한 마이크를 찾지 못했습니다.'
  if (error === 'no-speech') return '음성이 들리지 않았습니다. 다시 또렷하게 말해 주세요.'
  if (error === 'network') return '음성 인식 서비스에 연결하지 못했습니다.'
  if (error === 'aborted') return ''
  return '음성을 인식하는 중 문제가 발생했습니다.'
}

const editDistance = (left: string, right: string) => {
  const row = Array.from({ length: right.length + 1 }, (_, index) => index)
  for (let i = 1; i <= left.length; i += 1) {
    let previous = row[0]
    row[0] = i
    for (let j = 1; j <= right.length; j += 1) {
      const current = row[j]
      row[j] = Math.min(row[j] + 1, row[j - 1] + 1, previous + (left[i - 1] === right[j - 1] ? 0 : 1))
      previous = current
    }
  }
  return row[right.length]
}

export function analyzeSpeechTranscript(transcript: string, documentText: string, confidence = 1) {
  let normalized = transcript
  let suggested = transcript
  const uncertainWords = new Set<string>()
  const corrections: Array<{ before: string; after: string }> = []
  const addCorrection = (before: string, after: string) => {
    if (!before.trim() || before.trim() === after.trim()) return
    if (!corrections.some((item) => item.before === before && item.after === after)) corrections.push({ before, after })
  }
  if (/18\s*홀|십팔\s*홀/.test(documentText)) suggested = suggested.replace(/십팔흘|십팔\s*홀|십팔\s*일|18\s*일/g, (before) => {
    uncertainWords.add('18홀')
    if (before !== '18홀') addCorrection(before, '18홀')
    return '18홀'
  })
  if (/허리\s*숙임/.test(documentText)) suggested = suggested.replace(/허리\s*(?:숨김|숙임)/g, (before) => {
    uncertainWords.add('허리')
    uncertainWords.add('숙임')
    if (before !== '허리 숙임') addCorrection(before, '허리 숙임')
    return '허리 숙임'
  })

  const documentBrands = [...new Set(documentText.match(/\b[A-Z][A-Z0-9-]{2,}\b/g) ?? [])]
  const koreanLetterNames: Record<string, string> = {
    A: '에이', B: '비', C: '씨', D: '디', E: '이', F: '에프', G: '지', H: '에이치', I: '아이',
    J: '제이', K: '케이', L: '엘', M: '엠', N: '엔', O: '오', P: '피', Q: '큐', R: '알',
    S: '에스', T: '티', U: '유', V: '브이', W: '더블유', X: '엑스', Y: '와이', Z: '지',
  }
  for (const brand of documentBrands) {
    const spokenBrand = [...brand.replace(/[^A-Z]/g, '')].map((letter) => koreanLetterNames[letter] ?? '').join('')
    if (!spokenBrand) continue
    const spacedPattern = [...spokenBrand].join('\\s*')
    suggested = suggested.replace(new RegExp(spacedPattern, 'gi'), (before) => {
      uncertainWords.add(brand)
      if (before !== brand) addCorrection(before, brand)
      return brand
    })
  }
  suggested = suggested.replace(/\b[A-Za-z][A-Za-z0-9-]{2,}\b/g, (spoken) => {
    const upper = spoken.toUpperCase()
    const restored = documentBrands.find((brand) =>
      brand === upper || brand.startsWith(upper) || editDistance(brand, upper) <= 1,
    )
    if (restored && restored !== spoken) {
      uncertainWords.add(restored)
      addCorrection(spoken, restored)
    }
    return restored ?? spoken
  })

  // 자주 발생하는 한국어 STT 혼동은 문서에 올바른 표현이 실제로 있을
  // 때만 복원한다. 문맥과 무관한 과잉 교정을 피하기 위한 안전장치다.
  const documentAwareCorrections: Array<{ wrong: RegExp; right: string; document: RegExp }> = [
    { wrong: /올[래레]/g, right: '원래', document: /원래/ },
    { wrong: /십팔흘/g, right: '18홀', document: /(?:18|십팔)\s*홀/ },
    { wrong: /허리\s*숨김/g, right: '허리 숙임', document: /허리\s*숙임/ },
    { wrong: /시물레이션/g, right: '시뮬레이션', document: /시뮬레이션/ },
    { wrong: /촛점/g, right: '초점', document: /초점/ },
  ]
  for (const rule of documentAwareCorrections) {
    if (!rule.document.test(documentText)) continue
    suggested = suggested.replace(rule.wrong, (before) => {
      uncertainWords.add(rule.right)
      addCorrection(before, rule.right)
      return rule.right
    })
  }

  // 습관어는 사용자가 실제로 말한 내용이므로 자동 삭제하지 않는다.
  // 대신 교정 표에서 말하기 개선 제안으로 보여준다.
  const fillerPattern = /(?:^|[\s,.!?])((?:음+|어+|아+|저기|저|그게|그러니까|뭐랄까))(?=$|[\s,.!?])/g
  const fillers = [...transcript.matchAll(fillerPattern)].map((match) => match[1]).filter(Boolean)
  if (fillers.length > 0) {
    const fillerLabel = [...new Set(fillers)].slice(0, 4).join(' · ')
    fillers.forEach((filler) => uncertainWords.add(filler))
    addCorrection(fillerLabel, '1초 멈춘 뒤 핵심부터 말하기')
  }

  const englishFillers = transcript.match(/\b(?:um+|uh+|like|you know)\b/gi) ?? []
  if (englishFillers.length > 0) {
    englishFillers.forEach((filler) => uncertainWords.add(filler))
    addCorrection([...new Set(englishFillers.map((item) => item.toLowerCase()))].slice(0, 4).join(' · '), 'Pause briefly, then lead with the main point')
  }
  normalized = normalized.replace(/\s{2,}/g, ' ').trim()
  suggested = suggested.replace(/\s{2,}/g, ' ').trim()
  if (confidence > 0 && confidence < 0.65) {
    ;(normalized.match(/[가-힣A-Za-z0-9-]{2,}/g) ?? []).slice(0, 5).forEach((word) => uncertainWords.add(word))
  }
  return { text: normalized, suggestedText: suggested, uncertainWords: [...uncertainWords], corrections }
}

export function normalizeSpeechTranscript(transcript: string, documentText: string) {
  return analyzeSpeechTranscript(transcript, documentText).text
}
