import type { DocumentContext } from './documentParser'
import type { SupportedLanguage } from './language'

export type EvaluatorId = 'lumi' | 'real' | 'pressure' | 'teacher' | 'judge'

export interface EvaluatorProfile {
  id: EvaluatorId
  emoji: string
  name: string
  shortName: string
  description: string
  detail: string
  recommendation: string
  difficulty: string
  difficultyTone: 'green' | 'yellow' | 'orange' | 'red' | 'gold'
  traits: string[]
}

export const evaluatorProfiles: EvaluatorProfile[] = [
  { id: 'lumi', emoji: '😊', name: '루미 코치', shortName: '친절한 코치', description: '친절하게 알려드립니다.', detail: '답변마다 개선 방향과 자신감을 드려요.', recommendation: '처음 연습하는 분 추천', difficulty: '⭐', difficultyTone: 'green', traits: ['중간 힌트', '칭찬 → 개선 → 응원'] },
  { id: 'real', emoji: '⚖️', name: '박지훈 평가자', shortName: '실전형 면접관', description: '실전형 면접관', detail: '중간 힌트 없이 끝까지 듣고 평가해요.', recommendation: '실제 면접 대비', difficulty: '⭐⭐⭐', difficultyTone: 'yellow', traits: ['중간 평가 없음', '마지막 종합 평가'] },
  { id: 'teacher', emoji: '👨‍🏫', name: '코디 선생님', shortName: '척척박사 코디', description: '학습 내용을 확인', detail: '개념을 이해했는지 다정하고 똑똑하게 단계별로 질문해요.', recommendation: '시험·발표 연습', difficulty: '⭐⭐', difficultyTone: 'orange', traits: ['이해도 확인', '부족한 개념 재설명'] },
  { id: 'pressure', emoji: '🔥', name: '압박 면접관', shortName: '압박형 평가자', description: '논리와 근거를 집요하게 검증', detail: '모순과 근거 부족을 꼬리질문으로 파고들어요.', recommendation: '최종 면접 준비', difficulty: '⭐⭐⭐⭐⭐', difficultyTone: 'red', traits: ['꼬리질문 5개', '근거 반복 검증'] },
  { id: 'judge', emoji: '🏆', name: '심사위원', shortName: '발표 심사', description: '발표와 사업계획 평가', detail: '차별성, 시장성, 실현 가능성을 평가해요.', recommendation: '사업계획서·IR 발표', difficulty: '⭐⭐⭐⭐', difficultyTone: 'gold', traits: ['차별성·시장성', '실현 가능성·발표력'] },
]

const hasBatchim = (word: string) => {
  const last = word.trim().charCodeAt(word.trim().length - 1)
  return last >= 0xac00 && last <= 0xd7a3 && (last - 0xac00) % 28 !== 0
}

const josa = (word: string, consonant: string, vowel: string) => `${word}${hasBatchim(word) ? consonant : vowel}`

const operationalEntityPattern = /(TF|태스크포스|대응반|대책본부|담당관|본부|센터|부서|팀)$/i

/**
 * The parser normally selects the topic, but the final question generator must
 * never turn a department/contact label into the subject of a practice question.
 * This guard also handles Korean words split by PDF text extraction.
 */
function resolveQuestionTopic(context: DocumentContext, language: SupportedLanguage) {
  const evidence = [
    context.primaryTopic,
    context.coreClaim,
    context.supportingClaim,
    ...context.highlights,
  ].join(' ')
  const compactEvidence = evidence.replace(/\s+/g, '')
  const isCovidDocument = /(코로나(?:19)?|COVID-?19)/i.test(compactEvidence)
    && /(입원환자|예방수칙|손씻기|실내환기|기침예절|prevention|handwashing|ventilation|hospitali[sz]edpatients?)/i.test(compactEvidence)

  if (isCovidDocument) {
    const hasHospitalization = /(입원환자|hospitali[sz]edpatients?)/i.test(compactEvidence)
    if (language === 'en') {
      return hasHospitalization
        ? 'COVID-19 hospitalization trends and prevention guidelines'
        : 'COVID-19 prevention guidelines'
    }
    return hasHospitalization ? '코로나19 입원환자 증가와 예방수칙' : '코로나19 예방수칙'
  }

  const topic = context.primaryTopic.trim()
  if (!topic || operationalEntityPattern.test(topic)) {
    return language === 'en' ? 'the document’s main topic' : '문서의 핵심 주제'
  }
  return topic
}

/** 평가자별로 독립된 규칙을 사용하며, 질문 하나에는 하나의 평가 목적만 둡니다. */
export function generateEvaluatorQuestions(
  id: EvaluatorId,
  context: DocumentContext,
  mode: '면접' | '발표' | '시험',
  language: SupportedLanguage = 'ko',
) {
  const topic = resolveQuestionTopic(context, language)
  const subject = mode === '발표' ? `${topic} 사업화 계획` : `${topic} 핵심 내용`
  const topicGa = josa(topic, '이', '가')
  const topicEun = josa(topic, '은', '는')
  const subjectEul = josa(subject, '을', '를')

  // 시험은 제품·투자 심사가 아니라 문서의 개념과 사실 이해를 확인합니다.
  // 평가자 성격은 말투와 난이도에만 반영하고 평가 목적은 시험에 맞게 유지합니다.
  if (mode === '시험') {
    if (language === 'en') {
      if (id === 'lumi') return [
        `Let's start simply. What is the main idea of ${topic}?`,
        `Good. Why is ${topic} important according to the document?`,
        `What evidence does the document provide about ${topic}?`,
        `How should this information be applied in everyday life?`,
      ]
      if (id === 'pressure') return [
        context.documentType === 'pressRelease' || context.documentType === 'educational'
          ? `State the document's central message about ${topic} without using vague language.`
          : `Define ${topic} precisely without using vague language.`,
        `What single fact in the document best supports that explanation?`,
        `What common misunderstanding about ${topic} would make that answer incorrect?`,
        `If the document's evidence is limited, what can and cannot be concluded?`,
      ]
      if (id === 'judge') return [
        `State the central message of the document about ${topic}.`,
        `What cause or background does the document give for ${topic}?`,
        `Which numerical fact or example best supports the document's message?`,
        `What practical action does the document recommend?`,
      ]
      if (id === 'teacher') return [
        `Let's check the central idea first. What is the document's most important message about ${topic}?`,
        'What fact or number in the document best supports that message?',
        `What can and cannot be concluded about ${topic} from this document?`,
        'Give one practical example of applying the document’s recommendation.',
      ]
      return [
        `What is ${topic}?`,
        `Why is ${topic} important according to the document?`,
        `What evidence supports the document's explanation?`,
        `Give one practical example based on the document.`,
      ]
    }

    if (id === 'lumi') return [
      `좋아요! 먼저 ${topic}의 핵심 내용을 쉽게 설명해 볼까요?`,
      `잘하고 있어요. 문서에서는 왜 ${topicGa} 중요하다고 하나요?`,
      `${topic}에 관한 문서 속 근거나 수치 하나를 찾아 말해 볼까요?`,
      `마지막으로 이 내용을 일상에서 어떻게 실천할 수 있을까요?`,
    ]
    if (id === 'pressure') return [
      context.documentType === 'pressRelease' || context.documentType === 'educational'
        ? `문서가 ${topic}에 관해 전달하는 핵심 메시지를 모호한 표현 없이 설명해 보세요.`
        : `${topic}의 뜻을 모호한 표현 없이 정확히 설명해 보세요.`,
      `그 설명을 뒷받침하는 문서 속 가장 강한 사실 하나는 무엇입니까?`,
      `${topic}에 대해 흔히 할 수 있는 잘못된 설명은 무엇이며, 왜 틀렸습니까?`,
      `문서의 근거만으로 말할 수 있는 것과 말할 수 없는 것을 구분해 보세요.`,
    ]
    if (id === 'judge') return [
      `문서가 ${topic}에 관해 전달하는 핵심 메시지를 말씀해 주십시오.`,
      `문서에서는 ${topicGa} 중요해진 원인이나 배경을 무엇이라고 설명합니까?`,
      `${topic}에 관한 설명을 뒷받침하는 수치나 사례 하나를 말씀해 주십시오.`,
      `문서가 권고하는 구체적인 실천 방법은 무엇입니까?`,
    ]
    if (id === 'teacher') return [
      `척척박사 코디와 핵심부터 확인해 봐요. 문서가 ${topic}에 관해 전달하는 가장 중요한 메시지는 무엇인가요?`,
      '그 메시지를 뒷받침하는 문서 속 수치나 사실 하나를 설명해 주세요.',
      `${topic}에 관해 문서로 확인할 수 있는 내용과 단정할 수 없는 내용을 구분해 볼까요?`,
      '마지막으로 문서의 권고를 일상에서 실천하는 사례 하나를 말해 주세요.',
    ]
    return [
      `${topicEun} 무엇인지 본인의 말로 설명해 주세요.`,
      `문서에서는 왜 ${topicGa} 중요하다고 설명하나요?`,
      `그 설명을 뒷받침하는 문서 속 근거는 무엇인가요?`,
      `문서 내용을 적용한 구체적인 실천 사례를 하나 말해 주세요.`,
    ]
  }

  if (context.documentType === 'resume') {
    if (language === 'en') return [
      'Please summarize the strongest qualification shown in this document.',
      'Which experience in the document best proves that qualification?',
      'How would you apply that experience in the role you are seeking?',
      id === 'pressure' ? 'What weakness in this application would concern an interviewer most?' : 'What would you improve further for this role?',
    ]
    return [
      '이 자기소개서에서 가장 강조한 직무 역량을 말씀해 주세요.',
      '그 역량을 가장 잘 증명하는 경험은 무엇입니까?',
      '그 경험을 지원 직무에서 어떻게 활용할 수 있습니까?',
      id === 'pressure' ? '면접관이 이 지원 내용에서 가장 의심할 만한 약점은 무엇입니까?' : '지원 직무를 위해 앞으로 더 보완할 점은 무엇입니까?',
    ]
  }

  if (context.documentType !== 'businessPlan') {
    const styleLead = id === 'lumi' ? '좋아요! ' : id === 'pressure' ? '모호하게 말하지 말고, ' : ''
    if (language === 'en') return [
      `What is the single most important message of this ${context.documentType === 'pressRelease' ? 'press release' : 'document'}?`,
      'Which fact or number in the document best supports that message?',
      id === 'pressure' ? 'What conclusion would be an overstatement based on this evidence?' : 'What limitation or point of caution should the audience understand?',
      mode === '발표' ? 'What should the audience remember or do after hearing this presentation?' : 'How would you explain the practical meaning of this document?',
    ]
    return [
      `${styleLead}이 ${context.documentType === 'pressRelease' ? '보도자료' : '문서'}의 가장 중요한 메시지 한 가지를 말씀해 주세요.`,
      '그 메시지를 뒷받침하는 문서 속 수치나 사실은 무엇입니까?',
      id === 'pressure' ? '그 근거만으로 단정하면 안 되는 내용은 무엇입니까?' : '독자가 함께 알아야 할 한계나 주의점은 무엇입니까?',
      mode === '발표' ? '발표를 들은 청중이 기억하거나 실천해야 할 내용은 무엇입니까?' : '이 문서의 내용을 실제 상황에 어떻게 적용할 수 있습니까?',
    ]
  }

  if (language === 'en') {
    const englishSubject = mode === '발표' ? `${topic} business plan` : `the key ideas behind ${topic}`
    if (id === 'lumi') return [
      `Great! First, could you explain ${englishSubject} in your own words?`,
      `You're doing well. What is the single most important feature for users of ${topic}?`,
      `Now let's move to execution. What resource should you secure first for ${topic}?`,
    ]
    if (id === 'real') return [
      `Please explain the main objective of ${topic} objectively.`,
      `What evidence in the document supports the need for ${topic}?`,
      `What should be validated first to assess the feasibility of ${topic}?`,
    ]
    if (id === 'pressure') return [
      `Give me the single strongest piece of evidence that proves the need for ${topic}.`,
      `If you cannot prove the impact of ${topic} with numbers, how will you validate it?`,
      `Wouldn't ${topic} fail if the budget were insufficient?`,
      `How would you respond to the claim that ${topic} is no better than existing alternatives?`,
      `What decisive evidence makes you confident that ${topic} will succeed?`,
    ]
    if (id === 'teacher') return [
      `Let's start with the basics. What is ${topic}?`,
      `Why does the document say that ${topic} is needed?`,
      `How does ${topic} solve that problem?`,
      `Based on the document, please describe one real situation in which ${topic} would be used.`,
    ]
    return [
      `What is the most important difference between ${topic} and existing alternatives?`,
      `What core customer problem does ${topic} solve?`,
      `Which resource is most lacking to complete a working prototype of ${topic}?`,
      `Could you state the investment value of ${topic} in one sentence?`,
    ]
  }

  if (id === 'lumi') return [
    `좋아요! 먼저 ${subjectEul} 본인의 말로 쉽게 설명해 볼까요?`,
    `잘하고 있어요. ${topic} 고객에게 가장 필요한 기능 하나는 무엇일까요?`,
    `좋아요. 이제 실행 단계로 넘어가 볼게요. ${subject}에서 가장 먼저 확보해야 할 자원은 무엇일까요?`,
  ]

  if (id === 'real') return [
    `${topic}의 핵심 목적을 객관적으로 설명해 주십시오.`,
    `${topic}의 필요성을 뒷받침하는 문서 속 근거는 무엇입니까?`,
    `${topic}의 사업화 가능성을 판단하기 위해 가장 먼저 검증해야 할 항목은 무엇입니까?`,
  ]

  if (id === 'pressure') return [
    `${topic}의 필요성을 입증할 가장 강한 근거 하나만 말씀해 보세요.`,
    `${topic}의 효과를 숫자로 증명하지 못한다면 무엇으로 검증할 겁니까?`,
    `예산이 부족하면 ${topic}의 사업화 계획은 실패하는 것 아닙니까?`,
    `${topicGa} 기존 방식보다 낫지 않다는 반론에는 어떻게 답하시겠습니까?`,
    `${topic}의 성공을 확신하는 결정적 근거는 무엇입니까?`,
  ]

  if (id === 'teacher') return [
    `척척박사 코디와 기본부터 확인해 봐요. ${topicEun} 무엇인가요?`,
    `한 단계 더 가볼까요? 문서에서는 왜 ${topicGa} 필요하다고 설명하나요?`,
    `좋아요. 그렇다면 ${topicEun} 그 문제를 어떤 방식으로 해결하나요?`,
    `마지막으로 문서 내용을 바탕으로 ${topicGa} 실제로 사용되는 상황을 하나 설명해 주세요.`,
  ]

  return [
    `${topicGa} 기존 대안과 구별되는 가장 중요한 차별점은 무엇이라고 보십니까?`,
    `${topicGa} 해결하려는 고객의 핵심 문제는 무엇입니까?`,
    `${subject}에서 시제품 제작을 실제로 완료하기 위해 가장 부족한 자원은 무엇이라고 보십니까?`,
    `${topic}의 투자 가치를 한 문장으로 말씀해 주시겠습니까?`,
  ]
}

export function createInterimFeedback(id: EvaluatorId, answer: string, question = '', language: SupportedLanguage = 'ko', mode: '면접' | '발표' | '시험' = '면접') {
  const length = answer.replace(/\s/g, '').length
  const hasEvidence = /예를 들어|경험|사례|왜냐하면|때문에|for example|experience|case|because|\d/i.test(answer)
  if (mode === '시험') {
    const isSummary = /핵심|메시지|요약|무엇|main|message|summar/i.test(question)
    const isEvidenceQuestion = /근거|수치|사례|사실|evidence|number|fact|example/i.test(question)
    const isApplication = /실천|적용|방법|권고|action|apply|practice|recommend/i.test(question)
    const isLimitation = /한계|단정|오해|틀렸|limitation|overstatement|misunderstand/i.test(question)
    if (language === 'en') {
      if (isSummary) return 'Your summary is noted. Make the opening sentence even clearer, then support it in the next answer.'
      if (isEvidenceQuestion) return hasEvidence ? 'You identified evidence. Now explain what that fact proves.' : 'This question requires one exact fact or number from the document.'
      if (isApplication) return 'Your application is noted. Make the action more specific by stating who should do what.'
      if (isLimitation) return 'You identified a boundary. Clearly separate what the evidence proves from what it does not prove.'
      return hasEvidence ? 'You used evidence. Connect it to the conclusion more explicitly.' : 'Add one document-based fact to support the answer.'
    }
    const prefix = id === 'lumi' ? '좋아요! ' : id === 'pressure' ? '아직 부족합니다. ' : id === 'judge' ? '답변을 확인했습니다. ' : ''
    if (isSummary) return `${prefix}핵심 요약은 전달됐어요. 첫 문장을 한 문장 결론으로 더 선명하게 만들어 보세요.`
    if (isEvidenceQuestion) return hasEvidence
      ? `${prefix}문서 근거를 찾았어요. 이제 그 근거가 무엇을 증명하는지 연결해 보세요.`
      : `${prefix}이 질문에는 문서 속 정확한 수치나 사실 하나가 필요합니다.`
    if (isApplication) return `${prefix}적용 방향은 확인했어요. 누가 무엇을 해야 하는지 행동을 더 구체적으로 말해 보세요.`
    if (isLimitation) return `${prefix}문서 근거로 확인되는 범위와 단정할 수 없는 범위를 분리해 보세요.`
    return hasEvidence ? `${prefix}근거를 결론과 직접 연결해 보세요.` : `${prefix}문서 속 사실 하나를 답변에 추가해 보세요.`
  }
  if (language === 'en') {
    if (id === 'real') return 'Thank you. I have noted your answer. Let us move to the next question.'
    if (id === 'pressure') return length < 35 || !hasEvidence
      ? 'That is not enough evidence. Give me a concrete fact that supports your judgment.'
      : 'I heard your evidence, but it has not yet survived the counterargument. Answer the next question.'
    if (id === 'judge') return hasEvidence
      ? 'Your point is clear. In the next answer, connect it to customer demand, market size, or a measurable result.'
      : 'I understand the core point, but an investment decision requires concrete customer or market evidence.'
    if (id === 'teacher') return length < 25
      ? 'Let us begin with the definition: start with “This concept is…”'
      : hasEvidence ? 'Good understanding. In the next answer, explain the relationship between cause and effect.' : 'Good explanation. Now connect it to one real example.'
    return length < 25
      ? 'Good start! Add one sentence explaining why.'
      : hasEvidence ? 'Excellent—your main point and evidence were both clear. Lead with the conclusion again next time.' : 'Good main point. Add one real example or experience to make it more persuasive.'
  }
  if (id === 'real') return '답변 확인했습니다. 다음 질문으로 넘어가겠습니다.'
  if (id === 'pressure') {
    if (length < 35 || !hasEvidence) return '그 근거만으로는 부족합니다. 추상적인 설명 말고, 판단을 뒷받침할 구체적인 사실을 말씀해 보세요.'
    return '근거는 들었습니다. 하지만 그 근거가 반론까지 견딜 수 있는지는 아직 확인되지 않았습니다. 다음 질문에 답해 보세요.'
  }
  if (id === 'judge') {
    if (/차별|기존 대안/.test(question)) return hasEvidence
      ? '차별점은 확인했습니다. 다음에는 그 차이를 고객이 실제로 원하는지 검증하겠습니다.'
      : '차별점은 이해했습니다. 다음 답변에서는 고객 반응이나 비교 수치를 근거로 제시해 주시기 바랍니다.'
    if (/고객|문제/.test(question)) return '고객 문제는 확인했습니다. 그 문제가 얼마나 자주 발생하는지 보여 주는 근거가 있으면 시장성이 더 선명해집니다.'
    if (/자원|시제품|제작/.test(question)) return '필요 자원은 확인했습니다. 실제 심사에서는 필요한 금액과 확보 일정을 함께 제시해 주시기 바랍니다.'
    return hasEvidence
      ? '투자 가치는 전달됐습니다. 다음에는 시장 규모나 수익 가능성을 한 가지 수치로 뒷받침해 주십시오.'
      : '핵심 가치는 이해했습니다. 투자 판단을 위해 고객 수요나 시장 규모 근거가 필요합니다.'
  }
  if (id === 'teacher') {
    if (length < 25) return '핵심 개념의 정의부터 다시 말해 볼까요? “이 개념은 ○○이다”로 시작해 보세요.'
    if (!hasEvidence) return '개념 설명은 좋아요. 이제 실제 사례를 하나 연결해서 이해한 내용을 확인해 봅시다.'
    return '잘 이해하고 있어요. 다음 질문에서는 원인과 결과의 관계까지 설명해 보세요.'
  }
  if (length < 25) return '좋아요, 핵심은 시작했어요! 이번에는 이유를 한 문장만 더 붙여볼까요?'
  if (!hasEvidence) return '좋아요! 핵심은 잘 말씀하셨어요. 실제 경험이나 사례를 하나 더 넣으면 훨씬 설득력이 높아져요.'
  return '아주 좋아요! 핵심과 근거가 함께 들렸어요. 다음 답변도 결론부터 자신 있게 말해보세요.'
}

export function evaluatorReplyTitle(id: EvaluatorId, language: SupportedLanguage = 'ko') {
  if (language === 'en') {
    if (id === 'lumi') return "Lumi's quick coaching"
    if (id === 'real') return 'Evaluator feedback'
    if (id === 'pressure') return "The interviewer's challenge"
    if (id === 'teacher') return "Cody's concept check"
    return "The judge's review"
  }
  if (id === 'lumi') return '루미의 한 줄 코칭'
  if (id === 'real') return '박지훈 평가자'
  if (id === 'pressure') return '압박 면접관의 재질문'
  if (id === 'teacher') return '코디 선생님의 개념 점검'
  return '심사위원의 검토 의견'
}
