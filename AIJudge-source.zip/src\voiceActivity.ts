export interface VoiceActivitySample {
  activeSeconds: number
  elapsedSeconds: number
  level: number
  speaking: boolean
  currentSilenceSeconds: number
  thinkingPauses: number
  longPauses: number
  midSpeechBreaks: number
}

export interface VoiceActivityTracker {
  stop: () => void
}

interface VoiceActivityOptions {
  onSample: (sample: VoiceActivitySample) => void
  onFirstSpeech: (elapsedSeconds: number) => void
}

export async function startVoiceActivityTracking({ onSample, onFirstSpeech }: VoiceActivityOptions): Promise<VoiceActivityTracker> {
  if (!navigator.mediaDevices?.getUserMedia) throw new Error('Audio activity tracking is not supported.')

  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
  })
  const AudioContextClass = window.AudioContext
  const context = new AudioContextClass()
  const source = context.createMediaStreamSource(stream)
  const analyser = context.createAnalyser()
  analyser.fftSize = 512
  analyser.smoothingTimeConstant = 0.25
  source.connect(analyser)

  const samples = new Float32Array(analyser.fftSize)
  let frame = 0
  let stopped = false
  let activeMilliseconds = 0
  let lastVoiceAt = Number.NEGATIVE_INFINITY
  let firstSpeechDetected = false
  let lastTick = performance.now()
  const startedAt = lastTick
  let lastReport = 0
  let noiseFloor = 0.004
  let thinkingPauses = 0
  let longPauses = 0
  let midSpeechBreaks = 0
  let silenceStartedAt = 0
  let wasSpeaking = false

  const measure = (now: number) => {
    if (stopped) return
    analyser.getFloatTimeDomainData(samples)
    let energy = 0
    for (const value of samples) energy += value * value
    const rms = Math.sqrt(energy / samples.length)
    // 발화 시작에는 보수적인 임계값을 쓰고, 한 번 시작된 발화는 더 낮은
    // 유지 임계값을 사용한다. 이 히스테리시스가 작은 “음/어/아”가 매
    // 프레임마다 침묵으로 되돌아가는 현상을 막는다.
    const recentlyVoiced = firstSpeechDetected && now - lastVoiceAt <= 900
    const startThreshold = Math.max(0.008, noiseFloor * 1.85)
    const sustainThreshold = Math.max(0.0045, noiseFloor * 1.25)
    const rawVoice = rms >= (recentlyVoiced ? sustainThreshold : startThreshold)

    if (rawVoice) {
      lastVoiceAt = now
      if (!firstSpeechDetected) {
        firstSpeechDetected = true
        onFirstSpeech(Math.max(0.1, Math.round((now - startedAt) / 100) / 10))
      }
    } else if (!firstSpeechDetected || now - lastVoiceAt > 1500) {
      // 발화 직후의 꼬리음을 주변 소음으로 학습하면 다음 작은 소리를
      // 놓치게 된다. 충분히 긴 침묵에서만, 제한된 범위로 보정한다.
      noiseFloor = Math.min(0.0065, noiseFloor * 0.97 + Math.min(rms, 0.008) * 0.03)
    }

    // 짧은 습관어의 음절 사이 공백은 한 발화로 유지하되 650ms를 넘는
    // 실제 침묵은 발화 시간에 포함하지 않는다.
    const speaking = now - lastVoiceAt <= 650
    if (firstSpeechDetected && wasSpeaking && !speaking) silenceStartedAt = lastVoiceAt
    if (firstSpeechDetected && !wasSpeaking && speaking && silenceStartedAt > 0) {
      const silenceSeconds = (now - silenceStartedAt) / 1000
      if (silenceSeconds >= 5) longPauses += 1
      else if (silenceSeconds >= 2 && silenceSeconds < 4) thinkingPauses += 1
      if (silenceSeconds >= 1.2) midSpeechBreaks += 1
      silenceStartedAt = 0
    }
    wasSpeaking = speaking
    const delta = Math.min(100, Math.max(0, now - lastTick))
    if (speaking) activeMilliseconds += delta
    lastTick = now

    if (now - lastReport >= 100) {
      lastReport = now
      onSample({
        activeSeconds: Math.round(activeMilliseconds / 100) / 10,
        elapsedSeconds: Math.round((now - startedAt) / 100) / 10,
        level: Math.min(100, Math.round(rms / 0.12 * 100)),
        speaking,
        currentSilenceSeconds: firstSpeechDetected && !speaking
          ? Math.round((now - (silenceStartedAt || lastVoiceAt)) / 100) / 10
          : 0,
        thinkingPauses,
        longPauses,
        midSpeechBreaks,
      })
    }
    frame = requestAnimationFrame(measure)
  }

  frame = requestAnimationFrame(measure)

  return {
    stop: () => {
      if (stopped) return
      stopped = true
      cancelAnimationFrame(frame)
      source.disconnect()
      analyser.disconnect()
      stream.getTracks().forEach((track) => track.stop())
      void context.close()
    },
  }
}
