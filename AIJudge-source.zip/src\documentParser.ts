import { detectLanguage } from './language'

const cleanText = (text: string) =>
  text
    .split('\u0000').join(' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim()

async function readPdf(file: File) {
  const pdfjsLib = await import('pdfjs-dist')
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString()
  const pdf = await pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise
  if (pdf.numPages > 300) throw new Error('300페이지를 초과하는 PDF는 여러 파일로 나누어 업로드해 주세요.')
  const pages: string[] = []
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber)
    const content = await page.getTextContent()
    pages.push(content.items.map((item) => ('str' in item ? item.str : '')).join(' '))
    // 긴 PDF에서도 화면과 입력이 멈추지 않도록 주기적으로 브라우저에 제어권을 돌려줍니다.
    if (pageNumber % 5 === 0) await new Promise<void>((resolve) => window.setTimeout(resolve, 0))
  }
  return pages.join('\n')
}

async function readDocx(file: File) {
  const mammoth = (await import('mammoth')).default
  const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() })
  return result.value
}

async function readPptx(file: File) {
  const JSZip = (await import('jszip')).default
  const zip = await JSZip.loadAsync(await file.arrayBuffer())
  const slideNames = Object.keys(zip.files)
    .filter((name) => /^ppt\/slides\/slide\d+\.xml$/.test(name))
    .sort((a, b) => Number(a.match(/\d+/)?.[0]) - Number(b.match(/\d+/)?.[0]))

  const slides = await Promise.all(slideNames.map(async (name) => {
    const xml = await zip.file(name)?.async('text')
    if (!xml) return ''
    const document = new DOMParser().parseFromString(xml, 'application/xml')
    return Array.from(document.getElementsByTagName('a:p'))
      .map((paragraph) => Array.from(paragraph.getElementsByTagName('a:t'))
        .map((node) => node.textContent ?? '')
        .join('')
        .trim())
      .filter(Boolean)
      .join('\n')
  }))
  return slides.join('\n')
}

export async function extractDocumentText(file: File) {
  if (file.size > 20 * 1024 * 1024) throw new Error('파일 크기는 최대 20MB까지 업로드할 수 있습니다.')
  const extension = file.name.split('.').pop()?.toLowerCase()
  let text = ''

  if (extension === 'pdf') text = await readPdf(file)
  else if (extension === 'docx') text = await readDocx(file)
  else if (extension === 'pptx') text = await readPptx(file)
  else if (extension === 'ppt') throw new Error('구형 PPT 파일은 PPTX로 저장한 뒤 다시 업로드해 주세요.')
  else throw new Error('PDF, PPTX, DOCX 파일만 업로드할 수 있습니다.')

  const cleaned = cleanText(text).slice(0, 600_000)
  if (cleaned.length < 30) throw new Error('문서에서 질문을 만들 만큼 충분한 텍스트를 찾지 못했습니다.')
  return cleaned
}

const stopWords = new Set(['그리고', '그러나', '대한', '위한', '있는', '하는', '합니다', '입니다', '통해', '관련', '경우', '이번', '자료', '문서', '내용', '것으로', '수행', '아이디어', '개선', '개선하는', '발표', '계획'])

const referenceEntityPattern = /(협회|연구원|연구소|공단|공사|재단|위원회|대학교|대학|정부|부처|특허청|통계청|신문|일보|뉴스|주식회사|유한회사|법인|기관|출처|TF|태스크포스|대응반|대책본부|담당관|본부|센터|부서|팀)$/i
const productSubjectPattern = /(제품|서비스|기기|보조기|보조기기|장치|도구|플랫폼|솔루션|시스템|애플리케이션|어플리케이션|앱|기술|키트|프로그램)/

export type DocumentType = 'businessPlan' | 'studyMaterial' | 'contract' | 'paper' | 'pressRelease' | 'manual' | 'educational' | 'resume' | 'other'

const documentTypeRules: Array<{ type: DocumentType; patterns: RegExp[] }> = [
  { type: 'pressRelease', patterns: [/보도자료|보도참고자료|보도시점|배포일|브리핑|press release|media release/i] },
  { type: 'contract', patterns: [/계약서|계약기간|계약금|당사자|갑과 을|제\s*\d+\s*조|agreement|contract|party|terms and conditions/i] },
  { type: 'paper', patterns: [/초록|연구방법|연구결과|고찰|참고문헌|학술|abstract|methodology|results|discussion|references/i] },
  { type: 'businessPlan', patterns: [/사업계획|시장규모|수익모델|매출|투자|경쟁사|사업화|고객 세그먼트|business plan|market size|revenue model|investment|competitor/i] },
  { type: 'resume', patterns: [/자기소개서|지원동기|입사 후 포부|경력사항|직무역량|이력서|resume|curriculum vitae|cover letter|career objective/i] },
  { type: 'studyMaterial', patterns: [/시험범위|연습문제|정답|해설|퀴즈|평가문항|중간고사|기말고사|exam|quiz|answer key|practice question/i] },
  { type: 'manual', patterns: [/사용설명서|사용방법|설치방법|주의사항|고장|조작|매뉴얼|manual|instructions|installation|troubleshooting/i] },
  { type: 'educational', patterns: [/교육자료|학습목표|예방수칙|생활수칙|안내문|실천방법|교육|예방|학습|guideline|education|prevention|learning objective/i] },
]

export function classifyDocumentType(text: string): DocumentType {
  return classifyDocumentTypeWithConfidence(text)[0].type
}

export interface DocumentTypeCandidate {
  type: DocumentType
  confidence: number
}

export interface DocumentTypeEvidence {
  features: string[]
  cautions: string[]
}

export function analyzeDocumentTypeEvidence(text: string, type: DocumentType): DocumentTypeEvidence {
  const features: string[] = []
  const cautions: string[] = []
  const add = (condition: boolean, label: string) => { if (condition) features.push(label) }
  const sourceCount = (text.match(/https?:\/\/|www\.|\[[0-9]+\]|doi\s*:|참고문헌|출처\s*:/gi) ?? []).length
  const hasOfficialPublisher = /(질병관리청|보건복지부|교육부|통계청|식품의약품안전처|정부|공공기관|WHO|CDC|\.go\.kr|\.gov)/i.test(text)
  const years = [...text.matchAll(/\b((?:19|20)\d{2})\b/g)].map((match) => Number(match[1]))
  const newestYear = years.length ? Math.max(...years) : 0

  if (type === 'businessPlan') {
    add(/창업지원|사업계획서|사업계획|지원사업/.test(text), '창업지원사업·사업계획 양식')
    add(/시장분석|시장규모|목표시장|경쟁사|고객 세그먼트/.test(text), '시장분석 포함')
    add(/예산|사업비|자금조달|금액|원가|집행/.test(text), '예산·재무 항목 존재')
    add(/일정|추진계획|로드맵|마일스톤|개월|분기/.test(text), '일정·추진계획 존재')
    add(/수익모델|매출|판매가|마진/.test(text), '수익모델 항목 존재')
  } else if (type === 'pressRelease') {
    add(/보도자료|보도참고자료|보도시점|배포일/.test(text), '보도자료 표준 형식')
    add(/기자|작성자|담당자|문의/.test(text), '작성자·담당자 표시')
    add(/발표했다|밝혔다|전했다|설명했다|알렸다/.test(text), '보도자료 문체')
    add(years.length > 0, '발표 날짜 포함')
  } else if (type === 'paper') {
    add(/초록|abstract/i.test(text), '초록(Abstract) 포함')
    add(/참고문헌|references/i.test(text), '참고문헌 포함')
    add(/연구방법|방법론|methodology|methods/i.test(text), '연구방법 포함')
    add(/연구결과|결과|results/i.test(text), '연구결과 포함')
    add(/doi\s*:|학회|저널|journal/i.test(text), '학술 발행 정보 포함')
  } else if (type === 'contract') {
    add(/제\s*\d+\s*조/.test(text), '조항 구조 존재')
    add(/갑과 을|당사자|계약 당사자/.test(text), '계약 당사자 표시')
    add(/계약기간|효력|해지|위약/.test(text), '기간·효력·해지 조건 포함')
    add(/서명|날인/.test(text), '서명·날인 항목 존재')
  } else if (type === 'manual') {
    add(/사용방법|설치방법|조작방법|단계/.test(text), '사용 절차 포함')
    add(/주의사항|경고|위험/.test(text), '안전·주의사항 포함')
    add(/고장|문제 해결|문의|troubleshooting/i.test(text), '문제 해결 안내 포함')
  } else if (type === 'resume') {
    add(/지원동기/.test(text), '지원동기 포함')
    add(/경력|프로젝트|업무 경험/.test(text), '경력·경험 포함')
    add(/역량|강점|성과/.test(text), '역량·성과 포함')
    add(/입사 후 포부/.test(text), '입사 후 포부 포함')
  } else {
    add(/학습목표|교육목표/.test(text), '학습목표 포함')
    add(/예방수칙|실천방법|행동요령/.test(text), '실천·행동 지침 포함')
    add(/문제|퀴즈|정답|해설/.test(text), '문제·정답 구성 포함')
    add(/사례|예시/.test(text), '사례·예시 포함')
  }

  if (sourceCount > 0) features.push(`출처·인용 단서 ${sourceCount}개 확인`)
  if (features.length === 0) features.push('문서의 주요 표현과 구성 패턴이 해당 유형과 유사함')
  if (!newestYear) cautions.push('작성일과 자료 기준일을 확인해 주세요.')
  else if (newestYear < new Date().getFullYear() - 2) cautions.push(`일부 자료는 ${newestYear}년 기준일 수 있어 최신성 확인이 필요합니다.`)
  if (sourceCount === 0 && !(type === 'pressRelease' && hasOfficialPublisher)) cautions.push('핵심 주장에 연결된 출처나 인용을 추가로 확인해 주세요.')
  if (type === 'pressRelease' && !hasOfficialPublisher) cautions.push('공식 원문 링크 또는 실제 발행 기관을 확인해 주세요.')
  return { features: [...new Set(features)], cautions: [...new Set(cautions)] }
}

export function classifyDocumentTypeWithConfidence(text: string): DocumentTypeCandidate[] {
  const publicHealthGuidance = /(코로나|감염병|호흡기\s*감염|예방수칙|안전수칙|손\s*씻기|손씻기|마스크\s*착용|기침\s*예절|개인위생|방역수칙|생활수칙|COVID-?19|infection prevention|handwashing|safety guideline)/gi
  const publicHealthSignals = text.match(publicHealthGuidance)?.length ?? 0
  const hasBusinessPurpose = /(사업계획서|사업화|투자\s*(?:유치|가치|계획)|매출|수익모델|시장규모|판매가|목표\s*마진|경쟁사|시제품|business plan|commercialization|investment|revenue model|market size|prototype)/i.test(text)
  if (publicHealthSignals >= 2 && !hasBusinessPurpose) {
    const type: DocumentType = /보도자료|보도참고자료|보도시점|배포일|press release|media release/i.test(text)
      ? 'pressRelease'
      : 'educational'
    return [{ type, confidence: 100 }]
  }

  const scores = documentTypeRules.map(({ type, patterns }) => ({
    type,
    score: patterns.reduce((total, pattern) => total + ((text.match(new RegExp(pattern.source, `${pattern.flags.includes('g') ? pattern.flags : `${pattern.flags}g`}`)) ?? []).length), 0),
  })).filter((item) => item.score > 0)
  if (scores.length === 0) return [{ type: 'other', confidence: 100 }]
  const ranked = scores.sort((left, right) => right.score - left.score).slice(0, 3)
  const total = ranked.reduce((sum, item) => sum + item.score, 0)
  const candidates = ranked.map((item) => ({ type: item.type, confidence: Math.round(item.score / total * 100) }))
  candidates[0].confidence += 100 - candidates.reduce((sum, item) => sum + item.confidence, 0)
  return candidates
}

export const documentTypeLabels: Record<DocumentType, { ko: string; en: string }> = {
  businessPlan: { ko: '사업계획서', en: 'Business plan' },
  studyMaterial: { ko: '시험자료', en: 'Study material' },
  contract: { ko: '계약서', en: 'Contract' },
  paper: { ko: '논문', en: 'Research paper' },
  pressRelease: { ko: '보도자료', en: 'Press release' },
  manual: { ko: '설명서', en: 'Manual' },
  educational: { ko: '교육자료', en: 'Educational material' },
  resume: { ko: '자기소개서', en: 'Cover letter' },
  other: { ko: '기타', en: 'Other' },
}

export type DocumentTrustLevel = 'high' | 'review' | 'low'

export interface DocumentTrustAnalysis {
  score: number
  level: DocumentTrustLevel
  badges: Array<{ label: string; tone: 'green' | 'blue' | 'yellow' | 'orange' | 'red' }>
  checks: Array<{ label: string; status: 'good' | 'review' | 'warning'; detail: string }>
  disclaimer: string
}

export function analyzeDocumentTrust(text: string): DocumentTrustAnalysis {
  const explicitSource = /(출처|자료원|참고문헌|reference|source|https?:\/\/|www\.)/i.test(text)
  const hasCitation = /(\[[0-9]+\]|\([가-힣A-Za-z]+,?\s*\d{4}\)|doi\s*:|et al\.|참고문헌|각주)/i.test(text)
  const officialSignals = /(질병관리청|보건복지부|교육부|통계청|식품의약품안전처|정부|공공기관|대학교|학회|WHO|CDC|UNESCO|OECD|\.go\.kr|\.gov|\.edu)/i.test(text)
  const officialRelease = officialSignals && /(보도자료|보도참고자료|보도시점|배포일|담당자|문의|press release|media release)/i.test(text)
  const hasSource = explicitSource || officialRelease
  const suspiciousClaims = (text.match(/반드시|완벽하게|100\s*%|절대|무조건|기적|즉시 치료|완치|guaranteed|always|never|miracle cure/gi) ?? []).length
  const contradictionSignals = (text.match(/반면|그러나|하지만|상반|모순|일치하지|반박|however|contradict|inconsistent|on the other hand/gi) ?? []).length
  const hasDate = /(?:19|20)\d{2}[년.\-/]|(?:19|20)\d{2}\b/.test(text)
  let score = 35 + (hasSource ? 18 : 0) + (hasCitation ? 18 : 0) + (officialSignals ? 20 : 0) + (officialRelease ? 18 : 0) + (hasDate ? 8 : 0)
  score -= officialRelease ? Math.min(8, suspiciousClaims * 2) : Math.min(30, suspiciousClaims * 8)
  score -= Math.min(12, Math.max(0, contradictionSignals - 3) * 2)
  score = Math.max(0, Math.min(100, score))
  const level: DocumentTrustLevel = score >= 75 ? 'high' : score >= 45 ? 'review' : 'low'
  const badges: DocumentTrustAnalysis['badges'] = []
  if (officialSignals) badges.push({ label: '공식기관 자료 단서', tone: 'green' })
  if (/초록|abstract|참고문헌|references|doi\s*:|학회|저널|journal/i.test(text)) badges.push({ label: '학술자료 단서', tone: 'blue' })
  if (!officialSignals && !hasCitation && /(자기소개|에세이|소감|경험|블로그|작성자)/i.test(text)) badges.push({ label: '개인 작성 문서', tone: 'yellow' })
  if (!hasSource || (!hasCitation && !officialRelease)) badges.push({ label: '출처 확인 필요', tone: 'orange' })
  if (level === 'low' || (!officialRelease && suspiciousClaims >= 2)) badges.push({ label: '검증되지 않은 정보 가능성', tone: 'red' })
  if (badges.length === 0) badges.push({ label: '추가 확인 권장', tone: 'orange' })
  return {
    score,
    level,
    badges,
    checks: [
      { label: '출처 표시', status: hasSource ? 'good' : 'warning', detail: officialRelease ? '공식기관명과 보도자료 형식이 발행 출처 단서로 확인됩니다.' : hasSource ? '출처 또는 링크가 문서에서 확인됩니다.' : '출처나 원문 링크를 찾지 못했습니다.' },
      { label: '인용·참고문헌', status: hasCitation || officialRelease ? 'good' : 'review', detail: officialRelease ? '공식기관의 1차 보도자료이므로 일반 참고문헌 형식은 필수 요소가 아닙니다.' : hasCitation ? '인용 또는 참고문헌 형식이 확인됩니다.' : '주장을 뒷받침하는 인용 형식을 추가로 확인해 주세요.' },
      { label: '공식기관 단서', status: officialSignals ? 'good' : 'review', detail: officialSignals ? '공식기관·교육기관을 나타내는 표현이 있습니다. 실제 발행 여부는 원문에서 확인해야 합니다.' : '공식기관 발행 자료임을 확인할 단서가 부족합니다.' },
      { label: '내부 모순·과장 표현', status: suspiciousClaims > 0 && !officialRelease ? 'warning' : contradictionSignals > 3 ? 'review' : 'good', detail: suspiciousClaims > 0 && !officialRelease ? `단정적이거나 과장될 수 있는 표현이 ${suspiciousClaims}개 감지됐습니다.` : contradictionSignals > 3 ? '서로 다른 주장이나 반론 표현이 많아 문맥 확인이 필요합니다.' : '뚜렷한 과장 표현은 발견되지 않았습니다.' },
    ],
    disclaimer: '이 결과는 문서 내부 단서를 점검한 참고 정보입니다. 출처의 실제 존재, 최신성, 외부 사실의 진위까지 보장하지 않습니다.',
  }
}

const isReferenceEntity = (word: string) => referenceEntityPattern.test(word)
const isDescriptiveFragment = (word: string) =>
  /(하는|되는|있는|위한|통한|하여|하고|하며|하게|되게|않게|스럽게|하도록|하면서|했으며|했다|한다|됩니다|입니다|적으로|적이며|적인|적으)$/u.test(word)

function findKeywords(text: string) {
  const sourceWords = text.match(/[가-힣A-Za-z][가-힣A-Za-z0-9-]*/g) ?? []
  const particles = /(으로부터|에게서|에서는|으로는|이라고|이라는|까지는|부터는|에서는|에게는|으로|에서|에게|한테|보다|처럼|만큼|이라|라고|에는|에도|은|는|이|가|을|를|의|에|도|와|과|로|만)$/
  const referenceWords = new Set<string>()

  text.split(/\n+/).forEach((line) => {
    if (!/(출처|참고자료|자료\s*제공|발표\s*기관|조사\s*기관|담당\s*부서|담당자|책임자|문의처)/.test(line)) return
    ;(line.match(/[가-힣A-Za-z][가-힣A-Za-z0-9-]{3,}/g) ?? [])
      .forEach((word) => referenceWords.add(word.replace(particles, '').toLowerCase()))
  })
  for (const match of text.matchAll(/(?:주식회사|유한회사|㈜|\(주\))\s*([가-힣A-Za-z0-9-]{2,})/g)) {
    referenceWords.add(match[1].replace(particles, '').toLowerCase())
  }

  // PDF/PPT 텍스트 층에서 단어가 잘렸을 때, 같은 조각을 포함한 더 긴 원문 단어가
  // 존재하면 완전한 표기로 복원한다. 찾지 못한 3글자 이하 조각은 후보에서 버린다.
  const restoreOriginalWord = (word: string) => {
    if (word.length > 3) return word
    return sourceWords
      .filter((candidate) => candidate.length > 3 && candidate.includes(word))
      .sort((a, b) => b.length - a.length)[0] ?? ''
  }

  const counts = new Map<string, { count: number; original: string }>()
  sourceWords.forEach((sourceWord) => {
    if (isDescriptiveFragment(sourceWord)) return
    const restored = restoreOriginalWord(sourceWord)
    if (!restored) return

    const withoutParticle = restored.replace(particles, '')
    const original = withoutParticle.length > 3 ? withoutParticle : restored
    const normalized = original.toLowerCase()
    if (original.length <= 3 || stopWords.has(normalized) || referenceWords.has(normalized) || /^\d+$/.test(normalized) || isReferenceEntity(original) || isDescriptiveFragment(original)) return

    const current = counts.get(normalized)
    counts.set(normalized, { count: (current?.count ?? 0) + 1, original: current?.original ?? original })
  })

  return [...counts.values()]
    .sort((a, b) => b.count - a.count || b.original.length - a.original.length)
    .slice(0, 5)
    .map(({ original }) => original)
}

function findHighlights(text: string) {
  return text
    .split(/(?<=[.!?。])\s+|\n+/)
    .map((sentence) => sentence.trim())
    .filter((sentence) => sentence.length >= 18 && sentence.length <= 180)
    .filter((sentence) => !/(담당자|책임자|연락처|전화|팩스|보도시점|보도참고자료|배포일|배포\s*\d{4}|담당\s*부서|문의처|TF\b|☎|\d{2,4}-\d{3,4}-\d{4})/i.test(sentence))
    .slice(0, 8)
}

export interface DocumentContext {
  documentType: DocumentType
  primaryTopic: string
  secondaryTopic: string
  keywords: string[]
  highlights: string[]
  coreClaim: string
  supportingClaim: string
}

export function buildDocumentContext(text: string): DocumentContext {
  const language = detectLanguage(text)
  const documentType = classifyDocumentType(text)
  // PDF/PPT extraction may insert spaces inside Korean words (for example
  // `코 로 나 19`, `입 원 환 자`). Use a compact copy only for detection;
  // the original text is still preserved for quotations and evidence.
  const compactText = text.replace(/\s+/g, '')
  const keywords = findKeywords(text)
  const highlights = findHighlights(text)
  const fallback = cleanText(text).slice(0, 140) || '업로드한 문서의 핵심 내용'
  const productSubject = keywords.find((keyword) => productSubjectPattern.test(keyword))
  const excludedAcronyms = new Set(['PPT', 'PDF', 'DOCX', 'IR', 'AI', 'CEO', 'KPI', 'B2B', 'B2C'])
  const brandCounts = new Map<string, number>()
  // PPT 로고가 여러 텍스트 상자로 나뉘어 `G TAI`처럼 추출되는 경우를 복원한다.
  const brandText = text.replace(/\b([A-Z])\s+([A-Z][A-Z0-9-]{2,})\b/g, '$1$2')
  for (const brand of brandText.match(/\b[A-Z][A-Z0-9-]{2,}\b/g) ?? []) {
    if (!excludedAcronyms.has(brand)) brandCounts.set(brand, (brandCounts.get(brand) ?? 0) + 1)
  }
  const productBrand = [...brandCounts.entries()].sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)[0]?.[0]
  const isCovidGuidance = /(코로나(?:19)?|COVID-?19)/i.test(compactText)
    && /(입원환자|예방수칙|손씻기|실내환기|기침예절|prevention|handwashing|ventilation|hospitali[sz]edpatients?)/i.test(compactText)
  const publicHealthTopic = isCovidGuidance
    ? language === 'en'
      ? (/입원환자|hospitali[sz]edpatients?/i.test(compactText) ? 'COVID-19 hospitalization trends and prevention guidelines' : 'COVID-19 prevention guidelines')
      : (/입원환자/.test(compactText) ? '코로나19 입원환자 증가와 예방수칙' : '코로나19 예방수칙')
    : ''
  const primaryTopic = documentType === 'businessPlan'
    ? productBrand ?? productSubject ?? (language === 'en' ? 'the presented product' : '발표 제품')
    : publicHealthTopic || keywords[0] || (language === 'en' ? 'the document’s main topic' : '문서의 핵심 주제')
  const secondaryTopic = keywords.find((keyword) => keyword !== primaryTopic)
    ?? (documentType === 'businessPlan'
      ? (language === 'en' ? 'the product’s core value' : '제품의 핵심 가치')
      : (language === 'en' ? 'the document’s supporting point' : '문서의 보조 주제'))

  return {
    documentType,
    primaryTopic,
    secondaryTopic,
    keywords,
    highlights,
    coreClaim: highlights[0] ?? fallback,
    supportingClaim: highlights[1] ?? highlights[0] ?? fallback,
  }
}

export function generateQuestions(text: string, mode: '면접' | '발표' | '시험') {
  const keywords = findKeywords(text)
  const highlights = findHighlights(text)
  const key1 = keywords[0] ?? '문서의 핵심 주제'
  const key2 = keywords[1] ?? '주요 주장'
  const claim = highlights[0] ?? text.slice(0, 120)
  const context = claim.length > 72 ? `${claim.slice(0, 72)}…` : claim

  if (mode === '면접') return [
    `문서에서 강조한 “${key1}”과 관련해 본인이 직접 기여한 부분을 설명해 주세요.`,
    `“${key2}”을 추진하면서 가장 어려웠던 판단은 무엇이었고, 어떤 근거로 결정했나요?`,
    `문서의 핵심 내용인 “${context}”을 지원 직무에서 어떻게 활용할 수 있나요?`,
  ]
  if (mode === '발표') return [
    `이 자료에서 청중이 “${key1}”에 대해 반드시 기억해야 할 한 가지는 무엇인가요?`,
    `“${key2}”에 대한 주장을 뒷받침하는 가장 강한 근거를 설명해 주세요.`,
    `“${context}”에 반대하는 청중을 어떻게 설득하시겠습니까?`,
  ]
  return [
    `문서에서 다룬 “${key1}”의 개념을 본인의 말로 설명해 보세요.`,
    `“${key1}”과 “${key2}”은 어떤 관계가 있는지 구체적인 사례와 함께 설명해 주세요.`,
    `“${context}”의 의미와 한계를 함께 설명해 보세요.`,
  ]
}
